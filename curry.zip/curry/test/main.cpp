#include <iostream>
#include <conio.h>
#include <string>
#include <boost/timer.hpp>


struct Timer {
   ~Timer() {
      std::cout << "Test time: " << timer_.elapsed() << " sec." << std::endl;
      std::cout << "Press any key" << std::endl;
      getchar();
   };
   boost::timer timer_;
} timer;

#define BOOST_TEST_MODULE Test
#define BOOST_TEST_MAIN
#include <boost/test/included/unit_test.hpp>

#include <boost/typeof/typeof.hpp>
#include <boost/function.hpp>
#include "boost/curry/curry.hpp"

using namespace std;
using namespace boost;
using namespace unit_test;
using namespace unit_test_framework;


struct TimeChecker {
   ~TimeChecker() {
      std::cout << "Test time: " << timer_.elapsed() << " sec." << std::endl;
   };
   boost::timer timer_;
};

namespace TestPOD {
   struct test_function {
      string operator()() {
         return "string test_function::operator()()";
      };
      string operator()(int a) {
         return "string test_function::operator()(int:" + lexical_cast<string>(a) + ")";
      };
      string operator()(double a) {
         return "string test_function::operator()(double:" + lexical_cast<string>(a) + ")";
      };
      string operator()(int a, double b) {
         return "string test_function::operator()(int:" + lexical_cast<string>(a) + ", double:" + lexical_cast<string>(b) + ")";
      };
   };

   BOOST_AUTO_TEST_CASE(test_pod)
   {
      // setup curry
      boost::curry<string> m00;
      m00.entry(test_function());
      m00.entry<int>(test_function());
      m00.entry<int, double>(test_function());
      m00.entry<const int>(test_function());
      m00.entry<const int, const double>(test_function());

      // execute
      int i(100);
      double d(100.0);
      BOOST_CHECK_EQUAL(m00()(),       "string test_function::operator()()");
      BOOST_CHECK_EQUAL(m00()(i)(),    "string test_function::operator()(int:100)");
      BOOST_CHECK_EQUAL(m00()(i)(d)(), "string test_function::operator()(int:100, double:100)");

      // const value
      BOOST_CHECK_EQUAL(m00()(100)(),        "string test_function::operator()(int:100)");
      BOOST_CHECK_EQUAL(m00()(100)(100.0)(), "string test_function::operator()(int:100, double:100)");

      // with holder object (holder is similar to boost::any)
      boost::holder h0(100);
      boost::holder h1(100.0);
      BOOST_CHECK_EQUAL(m00()(h0)(), "string test_function::operator()(int:100)");
      BOOST_CHECK_EQUAL(m00()(h0)(h1)(), "string test_function::operator()(int:100, double:100)");

      // use boost::typeof
      BOOST_AUTO(c00, m00());       // curry<string>::args<void, void>
      BOOST_AUTO(c01, c00(100));    // curry<string>::args<const int, args<void, void> >
      BOOST_AUTO(c02, c01(100.0));   // curry<string>::args<const double, args<const int, args<void, void> > >
      BOOST_AUTO(r00, c02());       // string
      BOOST_CHECK_EQUAL(r00, "string test_function::operator()(int:100, double:100)");
   };

}


namespace TestUserClass {
   struct test_function {
      string operator()() {
         return "string test_function::operator()()";
      };
      template<typename T00>
      string operator()(T00& t00) {
         return "string test_function::operator()(T00:" + t00.name() + ")";
      };
      template<typename T00>
      string operator()(const T00& t00) {
         return "string test_function::operator()(const T00:" + t00.name() + ")";
      };
      template<typename T00, typename T01>
      string operator()(T00& t00, T01& t01) {
         return "string test_function::operator()(T00:" + t00.name() + ", T01:" + t01.name() + ")";
      };
      template<typename T00, typename T01>
      string operator()(const T00& t00, const T01& t01) {
         return "string test_function::operator()(const T00:" + t00.name() + ", const T01:" + t01.name() + ")";
      };
      template<typename T00, typename T01, typename T02>
      string operator()(T00& t00, T01& t01, T02& t02) {
         return "string test_function::operator()(T00:" + t00.name() + ", T01:" + t01.name() + ", T02:" + t02.name() + ")";
      };
      template<typename T00, typename T01, typename T02>
      string operator()(const T00& t00, const T01& t01, const T02& t02) {
         return "string test_function::operator()(const T00:" + t00.name() + ", const T01:" + t01.name() + ", const T02:" + t02.name() + ")";
      };
   };
   struct A {
      const string name() const { return "A"; };
   };
   struct B {
      const string name() const { return "B"; };
   };

   BOOST_AUTO_TEST_CASE(test_normal)
   {
      // setup curry
      boost::curry<string> m00;
      m00.entry(test_function());
      m00.entry<A>(test_function());
      m00.entry<B>(test_function());
      m00.entry<A, A>(test_function());
      m00.entry<A, B>(test_function());
      m00.entry<B, A>(test_function());
      m00.entry<B, B>(test_function());
      m00.entry<A, A, A>(test_function());
      m00.entry<const A>(test_function());
      m00.entry<const B>(test_function());
      m00.entry<const A, const A>(test_function());
      m00.entry<const A, const B>(test_function());
      m00.entry<const B, const A>(test_function());
      m00.entry<const B, const B>(test_function());
      m00.entry<const A, const A, const A>(test_function());

      // execute
      A a; B b;
      BOOST_CHECK_EQUAL(m00()(a)(),       "string test_function::operator()(T00:A)");
      BOOST_CHECK_EQUAL(m00()(a)(b)(),    "string test_function::operator()(T00:A, T01:B)");
      BOOST_CHECK_EQUAL(m00()(b)(a)(),    "string test_function::operator()(T00:B, T01:A)");
      BOOST_CHECK_EQUAL(m00()(b)(b)(),    "string test_function::operator()(T00:B, T01:B)");
      BOOST_CHECK_EQUAL(m00()(a)(a)(a)(), "string test_function::operator()(T00:A, T01:A, T02:A)");

      BOOST_CHECK_EQUAL(m00()(A())(),           "string test_function::operator()(const T00:A)");
      BOOST_CHECK_EQUAL(m00()(A())(B())(),      "string test_function::operator()(const T00:A, const T01:B)");
      BOOST_CHECK_EQUAL(m00()(B())(A())(),      "string test_function::operator()(const T00:B, const T01:A)");
      BOOST_CHECK_EQUAL(m00()(B())(B())(),      "string test_function::operator()(const T00:B, const T01:B)");
      BOOST_CHECK_EQUAL(m00()(A())(A())(A())(), "string test_function::operator()(const T00:A, const T01:A, const T02:A)");
   };


   // test specialization
   struct C {
      const string name() const { return "C"; };
   };

   template<> string test_function::operator()<C>(const C& c) {
      return "specialized operator()(const C:" + c.name() + ")";
   };
   template<> string test_function::operator()<C>(C& c) {
      return "specialized operator()(C:" + c.name() + ")";
   };


   BOOST_AUTO_TEST_CASE(test_specialize)
   {
      // setup curry
      boost::curry<string> m00;
      m00.entry(test_function());
      m00.entry<C>(test_function());
      m00.entry<const C>(test_function());

      // execute
      C c;
      BOOST_CHECK_EQUAL(m00()(c)(),       "specialized operator()(C:C)");
      BOOST_CHECK_EQUAL(m00()(C())(),     "specialized operator()(const C:C)");
   };

}

namespace TestReference {
   struct test_function {
      template<typename T00>
      string operator()(T00& t00) {
         t00.inclement();
         return "string test_function::operator()(T00:" + t00.count() + ")";
      };
   };
   struct A {
      A() : data_() {};
      unsigned int data_;
      void inclement() { ++data_; };
      const string count() const { return lexical_cast<string>(data_); };
   };

   BOOST_AUTO_TEST_CASE(test_normal)
   {
      // setup curry
      boost::curry<string> m00;
      m00.entry<A>(test_function());

      // execute
      A a00;
      BOOST_CHECK_EQUAL(m00()(a00)(),       "string test_function::operator()(T00:1)");
      BOOST_CHECK_EQUAL(m00()(a00)(),       "string test_function::operator()(T00:2)");
      BOOST_CHECK_EQUAL(m00()(a00)(),       "string test_function::operator()(T00:3)");
      BOOST_CHECK_EQUAL(m00()(a00)(),       "string test_function::operator()(T00:4)");
      A a01;
      BOOST_CHECK_EQUAL(m00()(a01)(),       "string test_function::operator()(T00:1)");
      BOOST_CHECK_EQUAL(m00()(a01)(),       "string test_function::operator()(T00:2)");
      BOOST_CHECK_EQUAL(m00()(a01)(),       "string test_function::operator()(T00:3)");
      BOOST_CHECK_EQUAL(m00()(a01)(),       "string test_function::operator()(T00:4)");
      holder a02;
      a02.reset<A>();
      BOOST_CHECK_EQUAL(m00()(a02)(),       "string test_function::operator()(T00:1)");
      BOOST_CHECK_EQUAL(m00()(a02)(),       "string test_function::operator()(T00:2)");
      BOOST_CHECK_EQUAL(m00()(a02)(),       "string test_function::operator()(T00:3)");
      BOOST_CHECK_EQUAL(m00()(a02)(),       "string test_function::operator()(T00:4)");
   };

}



namespace TestPerformance01 {
   struct test {
      int operator()(int a) { return a; };
      int operator()(int a, int, int, int, int) { return a; };
   };
   const unsigned int count = 100000;

   BOOST_AUTO_TEST_CASE(test_normal)
   {
      TimeChecker t;
      test m00;
      for (unsigned int i = 0; i < count; ++i) {
         BOOST_CHECK_EQUAL(m00(100), 100);
      };
   };

   BOOST_AUTO_TEST_CASE(test_function)
   {
      TimeChecker t;
      boost::function<int(int)> m00 = test();
      for (unsigned int i = 0; i < count; ++i) {
         BOOST_CHECK_EQUAL(m00(100), 100);
      };
   };

   BOOST_AUTO_TEST_CASE(test_curry)
   {
      TimeChecker t;
      boost::curry<int> m00;
      m00.entry<const int>(test());
      for (unsigned int i = 0; i < count; ++i) {
         BOOST_CHECK_EQUAL(m00()(100)(), 100);
      };
   };

}

namespace TestPerformance05 {
   struct test {
      int operator()(int a) { return a; };
      int operator()(int a, int, int, int, int) { return a; };
   };
   const unsigned int count = 100000;

   BOOST_AUTO_TEST_CASE(test_normal)
   {
      TimeChecker t;
      test m00;
      for (unsigned int i = 0; i < count; ++i) {
         BOOST_CHECK_EQUAL(m00(100, 100, 100, 100, 100), 100);
      };
   };

   BOOST_AUTO_TEST_CASE(test_function)
   {
      TimeChecker t;
      boost::function<int(int, int, int, int, int)> m00 = test();
      for (unsigned int i = 0; i < count; ++i) {
         BOOST_CHECK_EQUAL(m00(100, 100, 100, 100, 100), 100);
      };
   };

   BOOST_AUTO_TEST_CASE(test_curry)
   {
      TimeChecker t;
      boost::curry<int> m00;
      m00.entry<const int, const int, const int, const int, const int>(test());
      for (unsigned int i = 0; i < count; ++i) {
         BOOST_CHECK_EQUAL(m00()(100)(100)(100)(100)(100)(), 100);
      };
   };

}