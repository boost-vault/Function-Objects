#ifndef BOOST_CURRY_HPP
#define BOOST_CURRY_HPP
/*---------------------------------------------------------------------------
   curry.hpp

   ---------------------------------------------------------------------------
   Copyright (C) 2009/3 - 2009 Nowake fiercewinds.net
----------------------------------------------------------------------------*/

#include <typeinfo>
#include <map>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

#include <boost/function.hpp>

namespace boost {

// -special function to uniformize type_info ---------------------------------
// To get unique instance of type_info, multimethod's function use this function.
// Now we can use type_info's pointer to compare each type.
// ---------------------------------------------------------------------------
   namespace detail {
      namespace curry {
         template<typename T>
         struct type {
            static const std::type_info& typeinfo() {
               static const std::type_info& r(typeid(T));
               return r;
            }
         };
         template<typename T>
         struct type<const T> {
            struct id {};
            static const std::type_info& typeinfo() {
               static const std::type_info& r(typeid(id));
               return r;
            }
         };
      }
   }

// -holder class--------------------------------------------------------------
// Special class for multimethod.
// This class is created by reference to boost::any and added some functions.
// ---------------------------------------------------------------------------
   namespace detail {
      namespace curry {
         class container {
         public:
            virtual const std::type_info& type() const = 0;
            virtual const std::type_info& id() const = 0;
            virtual boost::shared_ptr<container> clone() const = 0;
            virtual boost::shared_ptr<container> fission() const = 0;
         };


         template<typename T>
         class container_base : public container {
         public:
            typedef T content_type;
            virtual const std::type_info& type() const { return boost::detail::curry::type<content_type>::typeinfo(); };
            virtual const std::type_info& id() const { return boost::detail::curry::type<container_base>::typeinfo(); };
            content_type& content() { return content_; };
         protected:
            container_base() : content_() {};
            template<typename A1>
            container_base(A1& v1) : content_(v1) {};
            template<typename A1, typename A2>
            container_base(A1& v1, A2& v2) : content_(v1, v2) {};
            template<typename A1, typename A2, typename A3>
            container_base(A1& v1, A2& v2, A3& v3) : content_(v1, v2, v3) {};
            template<typename A1, typename A2, typename A3, typename A4>
            container_base(A1& v1, A2& v2, A3& v3, A4& v4) : content_(v1, v2, v3, v4) {};
            ~container_base() {};
            content_type content_;
         };


         template<typename T>
         class value_container : public container_base<T> {
         public:
            typedef T content_type;
            typedef container_base base_type;
            virtual boost::shared_ptr<container> clone() const {
               return boost::shared_ptr<value_container>(new value_container(content_), deleter());
            };
            virtual boost::shared_ptr<container> fission() const { return clone(); };
         public:
            static boost::shared_ptr<value_container> create() {
               return boost::shared_ptr<value_container>(new value_container, deleter());
            };
            template<typename A1>
            static boost::shared_ptr<value_container> create(A1& a1) {
               return boost::shared_ptr<value_container>(new value_container(a1), deleter());
            };
            template<typename A1, typename A2>
            static boost::shared_ptr<value_container> create(A1& a1, A2& a2) {
               return boost::shared_ptr<value_container>(new value_container(a1, a2), deleter());
            };
            template<typename A1, typename A2, typename A3>
            static boost::shared_ptr<value_container> create(A1& a1, A2& a2, A3& a3) {
               return boost::shared_ptr<value_container>(new value_container(a1, a2, a3), deleter());
            };
            template<typename A1, typename A2, typename A3, typename A4>
            static boost::shared_ptr<value_container> create(A1& a1, A2& a2, A3& a3, A4& a4) {
               return boost::shared_ptr<value_container>(new value_container(a1, a2, a3, a4), deleter());
            };
         protected:
            value_container() : base_type() {};
            template<typename A1>
            value_container(A1& v1) : base_type(v1) {};
            template<typename A1, typename A2>
            value_container(A1& v1, A2& v2) : base_type(v1, v2) {};
            template<typename A1, typename A2, typename A3>
            value_container(A1& v1, A2& v2, A3& v3) : base_type(v1, v2, v3) {};
            template<typename A1, typename A2, typename A3, typename A4>
            value_container(A1& v1, A2& v2, A3& v3, A4& v4) : base_type(v1, v2, v3, v4) {};
            ~value_container() {};
            struct deleter { void operator()(value_container* value) { delete value; }; };
            friend deleter;
         };


         template<typename T>
         class shared_container : public container_base<T>, public boost::enable_shared_from_this<shared_container<T> > {
         public:
            typedef T content_type;
            typedef container_base base_type;
            virtual boost::shared_ptr<container> clone() const {
               return boost::shared_ptr<shared_container>(new shared_container(content_), deleter());
            };
            virtual boost::shared_ptr<container> fission() const { return shared_from_this(); };
         public:
            static boost::shared_ptr<shared_container> create() {
               return boost::shared_ptr<shared_container>(new shared_container, deleter());
            };
            template<typename A1>
            static boost::shared_ptr<shared_container> create(A1& a1) {
               return boost::shared_ptr<shared_container>(new shared_container(a1), deleter());
            };
            template<typename A1, typename A2>
            static boost::shared_ptr<shared_container> create(A1& a1, A2& a2) {
               return boost::shared_ptr<shared_container>(new shared_container(a1, a2), deleter());
            };
            template<typename A1, typename A2, typename A3>
            static boost::shared_ptr<shared_container> create(A1& a1, A2& a2, A3& a3) {
               return boost::shared_ptr<shared_container>(new shared_container(a1, a2, a3), deleter());
            };
            template<typename A1, typename A2, typename A3, typename A4>
            static boost::shared_ptr<shared_container> create(A1& a1, A2& a2, A3& a3, A4& a4) {
               return boost::shared_ptr<shared_container>(new shared_container(a1, a2, a3, a4), deleter());
            };
         protected:
            shared_container() : base_type() {};
            template<typename A1>
            shared_container(A1& v1) : base_type(v1) {};
            template<typename A1, typename A2>
            shared_container(A1& v1, A2& v2) : base_type(v1, v2) {};
            template<typename A1, typename A2, typename A3>
            shared_container(A1& v1, A2& v2, A3& v3) : base_type(v1, v2, v3) {};
            template<typename A1, typename A2, typename A3, typename A4>
            shared_container(A1& v1, A2& v2, A3& v3, A4& v4) : base_type(v1, v2, v3, v4) {};
            ~shared_container() {};
            struct deleter { void operator()(shared_container* value) { delete value; }; };
            friend deleter;
         };


         class bad_clone : public std::exception {
         public:
            virtual const char * what() const throw() {
               return "Bad holder clone: this is noncopyable container.";
            };
         };

         template<typename T>
         class noncopyable_container : public container_base<T> {
         public:
            typedef T content_type;
            typedef container_base base_type;
            virtual boost::shared_ptr<container> clone() const { throw bad_clone(); };
            virtual boost::shared_ptr<container> fission() const { throw bad_clone(); };
         public:
            static boost::shared_ptr<noncopyable_container> create() {
               return boost::shared_ptr<noncopyable_container>(new noncopyable_container, deleter());
            };
            template<typename A1>
            static boost::shared_ptr<noncopyable_container> create(A1& a1) {
               return boost::shared_ptr<noncopyable_container>(new noncopyable_container(a1), deleter());
            };
            template<typename A1, typename A2>
            static boost::shared_ptr<noncopyable_container> create(A1& a1, A2& a2) {
               return boost::shared_ptr<noncopyable_container>(new noncopyable_container(a1, a2), deleter());
            };
            template<typename A1, typename A2, typename A3>
            static boost::shared_ptr<noncopyable_container> create(A1& a1, A2& a2, A3& a3) {
               return boost::shared_ptr<noncopyable_container>(new noncopyable_container(a1, a2, a3), deleter());
            };
            template<typename A1, typename A2, typename A3, typename A4>
            static boost::shared_ptr<noncopyable_container> create(A1& a1, A2& a2, A3& a3, A4& a4) {
               return boost::shared_ptr<noncopyable_container>(new noncopyable_container(a1, a2, a3, a4), deleter());
            };
         protected:
            noncopyable_container() : container_base<T, noncopyable_container>() {};
            template<typename A1>
            noncopyable_container(A1& v1) : base_type(v1) {};
            template<typename A1, typename A2>
            noncopyable_container(A1& v1, A2& v2) : base_type(v1, v2) {};
            template<typename A1, typename A2, typename A3>
            noncopyable_container(A1& v1, A2& v2, A3& v3) : base_type(v1, v2, v3) {};
            template<typename A1, typename A2, typename A3, typename A4>
            noncopyable_container(A1& v1, A2& v2, A3& v3, A4& v4) : base_type(v1, v2, v3, v4) {};
            ~noncopyable_container() {};
            struct deleter { void operator()(noncopyable_container* value) { delete value; }; };
            friend deleter;
         };


         template<typename T>
         class reference_container : public container, public boost::enable_shared_from_this<reference_container<T> > {
         public:
            typedef T content_type;
            virtual const std::type_info& type() const { return boost::detail::curry::type<content_type>::typeinfo(); };
            content_type& content() { return content_; };
            virtual boost::shared_ptr<container> clone() const { throw bad_clone(); };
            virtual boost::shared_ptr<container> fission() const { return shared_from_this(); };
         public:
            static boost::shared_ptr<reference_container> create(content_type& a1) {
               return boost::shared_ptr<reference_container>(new reference_container(a1), deleter());
            };
         protected:
            reference_container(content_type& v1) : content_(v1) {};
            ~reference_container() {};
            content_type& content_;
            struct deleter { void operator()(reference_container* value) { delete value; }; };
            friend deleter;
         };
      }
   }

   class holder {
   public:
      template<typename content_type>
      struct container_traits {
         static boost::shared_ptr<detail::curry::container> create() { return detail::curry::value_container<content_type>::create(); };
         template<typename A1>
         static boost::shared_ptr<detail::curry::container> create(A1& v1) { return detail::curry::value_container<content_type>::create(v1); };
         template<typename A1, typename A2>
         static boost::shared_ptr<detail::curry::container> create(A1& v1, A2& v2) { return detail::curry::value_container<content_type>::create(v1, v2); };
         template<typename A1, typename A2, typename A3>
         static boost::shared_ptr<detail::curry::container> create(A1& v1, A2& v2, A3& v3) { return detail::curry::value_container<content_type>::create(v1, v2, v3); };
         template<typename A1, typename A2, typename A3, typename A4>
         static boost::shared_ptr<detail::curry::container> create(A1& v1, A2& v2, A3& v3, A4& v4) { return detail::curry::value_container<content_type>::create(v1, v2, v3, v4); };
      };

   public:
      holder() : container_() {};

      template<typename content_type>
      holder(const content_type& content) : container_(container_traits<content_type>::create(content)) {};

      template<typename content_type, template<typename> class container_type>
      holder(const content_type& content) : container_(container_detail::curry::type<content_type>::create(content)) {};

      holder(const holder& other) : container_() {
         if (!other.container_.get()) return;
         container_ = other.container_->fission();
      };

      ~holder() {};

    public:
      holder& swap(holder& other) {
         container_.swap(other.container_);
         return *this;
      }

      template<typename T>
      holder& operator=(const T& other) {
         holder(other).swap(*this);
         return *this;
      }

      holder& operator=(const holder& other) {
         holder(other).swap(*this);
         return *this;
      }

      holder reference() {
         holder r;
         r.container_ = container_;
         return r;
      };

      void reset() {
         container_.reset();
      };

      template<typename content_type>
      void reset() {
         container_ = container_traits<content_type>::create();
      };

      template<typename content_type, typename A0>
      void reset(A0& a0) {
         container_ = container_traits<content_type>::create(a0);
      };

      template<typename content_type, typename A0, typename A1>
      void reset(A0& a0, A1& a1) {
         container_ = container_traits<content_type>::create(a0, a1);
      };

      template<typename content_type, typename A0, typename A1, typename A2>
      void reset(A0& a0, A1& a1, A2& a2) {
         container_ = container_traits<content_type>::create(a0, a1, a2);
      };

      template<typename content_type, typename A0, typename A1, typename A2, typename A3>
      void reset(A0& a0, A1& a1, A2& a2, A3& a3) {
         container_ = container_traits<content_type>::create(a0, a1, a3);
      };

      template<typename content_type, template<typename> class container_type>
      void reset() {
         container_ = container_type<content_type>::create();
      };

      template<typename content_type, template<typename> class container_type, typename A0>
      void reset(A0& a0) {
         container_ = container_type<content_type>::create(a0);
      };

      template<typename content_type, template<typename> class container_type, typename A0, typename A1>
      void reset(A0& a0, A1& a1) {
         container_ = container_type<content_type>::create(a0, a1);
      };

      template<typename content_type, template<typename> class container_type, typename A0, typename A1, typename A2>
      void reset(A0& a0, A1& a1, A2& a2) {
         container_ = container_type<content_type>::create(a0, a1, a2);
      };

      template<typename content_type, template<typename> class container_type, typename A0, typename A1, typename A2, typename A3>
      void reset(A0& a0, A1& a1, A2& a2, A3& a3) {
         container_ = container_type<content_type>::create(a0, a1, a3);
      };

    public:
      bool empty() const {
         return !(container_.get());
      }
      
      const std::type_info& type() const {
         return container_ ? container_->type() : boost::detail::curry::type<void>::typeinfo();
      }
      
      const std::type_info& id() const {
         return container_ ? container_->id() : boost::detail::curry::type<detail::curry::container_base<void> >::typeinfo();
      }

      template<typename T>
      T* cast() {
         return container_.get() && container_->type() == boost::detail::curry::type<T>::typeinfo() ? unsafe<T>() : 0;
      }

      template<typename T>
      T* unsafe() {
         return &(static_cast<detail::curry::container_base<T>*>(container_.get())->content());
      }

   private:
      boost::shared_ptr<detail::curry::container> container_;

   };


   class bad_holder_cast : public std::bad_cast {
   public:
      virtual const char * what() const throw() {
         return "bad_holder_cast: "
                "failed conversion using holder_cast";
      }
   };


   template<typename T>
   inline T* holder_cast(holder* target) {
      return target ? target->cast<T>() : 0;
   }

   template<typename T>
   inline const T* holder_cast(const holder* target) {
      return holder_cast<T>(const_cast<holder*>(target));
   }

   template<typename T>
   T holder_cast(holder& target) {
      typedef BOOST_DEDUCED_TYPENAME remove_reference<T>::type nonref;
      nonref* result = holder_cast<nonref>(&target);
      if(result) return *result;
      throw bad_holder_cast();
   }

   template<typename T>
   inline T holder_cast(const holder& target) {
      typedef BOOST_DEDUCED_TYPENAME remove_reference<T>::type nonref;
      return holder_cast<const nonref&>(const_cast<holder&>(target));
   }



// -curry---------------------------------------------------------------------
// ---------------------------------------------------------------------------
   namespace detail {
      namespace curry {
         class bad_method : public std::bad_cast {
         public:
            virtual const char * what() const throw() {
               return "Bad method apply: no entried argument set.";
            };
         };

         struct argument_traits {
            typedef const std::type_info* id_type;
            template<typename T>
            static id_type id(T& target) { return &(boost::detail::curry::type<T>::typeinfo()); };
            static id_type id(holder& target) { return &(target.id()); };
            template<typename T>
            static id_type id() { return &(boost::detail::curry::type<T>::typeinfo()); };
            template<typename R>
            struct cast_traits {
               template<typename T>
               static R cast(T& target) { return R(target); };
               static R& cast(R& target) { return target; };
               static R& cast(holder& target) { return holder_cast<R&>(target); };
            };
         };

         struct apply_traits {   //workaround for template typedef
            template<typename R>
            struct result_traits {
               template<typename T> R operator()(T& t) { return R(t); };
               template<typename T> R operator()(const T& t) { return R(t); };
               template<> R operator()(R& t) { return t; };
               template<> R operator()(const R& t) { return t; };
            };

            template<typename R, typename T = result_traits<R> >
            struct impl {
               T result;
               template<typename A00> R operator()(A00& a00) { return result(a00()); };
               template<typename A00, typename A01> R operator()(A00& a00, A01& a01) { return result(a00(a01)); };
               template<typename A00, typename A01, typename A02> R operator()(A00& a00, A01& a01, A02& a02) { return result(a00(a01, a02)); };
               template<typename A00, typename A01, typename A02, typename A03> R operator()(A00& a00, A01& a01, A02& a02, A03& a03) { return result(a00(a01, a02, a03)); };
            };

            template<>
            struct impl<void> {
               template<typename A00> void operator()(A00& a00) { a00(); };
               template<typename A00, typename A01> void operator()(A00& a00, A01& a01) { a00(a01); };
               template<typename A00, typename A01, typename A02> void operator()(A00& a00, A01& a01, A02& a02) { a00(a01, a02); };
               template<typename A00, typename A01, typename A02, typename A03> void operator()(A00& a00, A01& a01, A02& a02, A03& a03) { a00(a01, a02, a03); };
            };
         };

         struct return_empty_value {
            template<typename R>
            struct impl {
               template<typename A00> R operator()(A00& a00) { a00(); return R(); };
               template<typename A00, typename A01> R operator()(A00& a00, A01& a01) { a00(a01); return R(); };
               template<typename A00, typename A01, typename A02> R operator()(A00& a00, A01& a01, A02& a02) { a00(a01, a02); return R(); };
               template<typename A00, typename A01, typename A02, typename A03> R operator()(A00& a00, A01& a01, A02& a02, A03& a03) { a00(a01, a02, a03); return R(); };
            };
         };
      }
   }

// -curry owner---------------------------------------------------------------
// ---------------------------------------------------------------------------
   template<typename result_t, typename holder_t = holder, class apply_t = detail::curry::apply_traits, class argument_t = detail::curry::argument_traits>
   class curry {
   public:
      typedef result_t result_type;
      typedef holder_t holder_type;
      typedef holder_t HHH;
      typedef typename argument_t::id_type id_type;
      typedef apply_t apply_traits;
      typedef argument_t argument_traits;
      class method;
      template<typename arg_t, typename args_t> class args;
      typedef args<void, void> executor_type;
   public:
      curry() : root_() {};

   // -argument holder-----------------------------------------------------------
   // ---------------------------------------------------------------------------
      template<typename derived_t, typename arg_t, typename args_t>
      class args_base {
      public:
         typedef derived_t derived_type;
         typedef arg_t arg_type;
         typedef args_t args_type;
         typedef method method_type;
         args_base(method_type& method) : method_(method) {};
         template<typename T>
         args<T, derived_type> operator()(T& target) {
            return args<T, derived_type>(method_.find(target), target, (*static_cast<derived_type*>(this)));
         };
         template<typename T>
         args<const T, derived_type> operator()(const T& target) {
            return args<const T, derived_type>(method_.find(target), target, (*static_cast<derived_type*>(this)));
         };
         result_type operator()() { return method_(*(static_cast<derived_type*>(this))); };
         method_type& method() { return method_; };
      protected:
         method_type& method_;
      };

      template<typename arg_t, typename args_t>
      class args : public args_base<args<arg_t, args_t>, arg_t, args_t> {
      public:
         typedef arg_t arg_type;
         typedef args_t args_type;
         args(typename curry::method& m, arg_type& arg, args_type& args) : args_base(m), arg_(arg), args_(args) {};
         arg_type& head() { return arg_; };
         args_type& body() { return args_; };
      private:
         arg_type& arg_;
         args_type args_;
      };

      template<>
      class args<void, void> : public args_base<args<void, void>, void, void> {
      public:
         args(typename curry::method& m) : args_base(m) {};
      };

   // -caller--------------------------------------------------------------------
   // ---------------------------------------------------------------------------
      executor_type executor() { return args<void, void>(root_); };
      executor_type operator()() { return executor(); };

   // -method holder-------------------------------------------------------------
   // ---------------------------------------------------------------------------
      class method {
      public:
         typedef std::map<const id_type, method> methods_type;
         template<typename T>
         method& find(T& target) {
            std::pair<methods_type::iterator, bool> r(methods_.insert(make_pair(argument_traits::id(target), method())));
            return r.first->second;
         };
         method& find(holder& target) {
            std::pair<methods_type::iterator, bool> r(methods_.insert(make_pair(argument_traits::id(target), method())));
            return r.first->second;
         };
         template<typename T>
         method& find() {
            std::pair<methods_type::iterator, bool> r(methods_.insert(make_pair(argument_traits::id<T>(), method())));
            return r.first->second;
         };
         template<typename T>
         result_type operator()(T& args) {
            if (trampoline_.empty()) throw detail::curry::bad_method();
            typedef result_type (*trampoline_type)(holder&, T&);
            return  (*(trampoline_.cast<trampoline_type>()))(function_, args);
         };
      private:
         friend curry;
         holder trampoline_;
         holder function_;
         methods_type methods_;
      };
   private:
      method root_;

   public:
      // -helper--------------------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename T, typename A> struct finder;
      template<typename A> struct finder<holder_type, A> {
         static method& find(method& target) {
            return target.find<detail::curry::container_base<A> >();
         };
      };
      template<typename A> struct finder<A, A> {
         static method& find(method& target) {
            return target.find<A>();
         };
      };
      // -caller for 0-arg----------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename F>
      struct trampoline00 {
         struct reflect {
            typedef args<void, void> args_type;
            typedef result_type (*trampoline_type)(holder&, args_type&);
            static result_type caller(holder& function, args_type& arguments) {
               return (*function.unsafe<F>())();
            };
            static void setup(method& root, F& f) {
               method& target(root);
               target.function_ = f;
               target.trampoline_ = &reflect::caller;
            };
         };
      };
      template<typename F>
      bool entry(F& f) {
         trampoline00<F>::reflect::setup(root_, f);
         return true;
      };
      // -caller for 1-arg----------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename F, typename A00>
      struct trampoline01 {
         template<typename T00>
         struct reflect {
            typedef args<T00, args<void, void> > args_type;
            typedef result_type (*trampoline_type)(holder&, args_type&);
            static result_type caller(holder& function, args_type& arguments) {
               return (*function.unsafe<F>())(
                  argument_traits::cast_traits<A00>::cast(arguments.head())
                  );
            };
            static void setup(method& root, F& f) {
               method& target(finder<T00, A00>::find(root));
               target.function_ = f;
               target.trampoline_ = &reflect::caller;
            };
         };
      };
      template<typename A00, typename F>
      bool entry(F& f) {
         trampoline01<F, A00>::reflect<A00>::setup(root_, f);
         trampoline01<F, A00>::reflect<HHH>::setup(root_, f);
         return true;
      };
      // -caller for 2-arg----------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename F, typename A00, typename A01>
      struct trampoline02 {
         template<typename T00, typename T01>
         struct reflect {
            typedef args<T01, args<T00, args<void, void> > > args_type;
            typedef result_type (*trampoline_type)(holder&, args_type&);
            static result_type caller(holder& function, args_type& arguments) {
               return (*function.unsafe<F>())(
                  argument_traits::cast_traits<A00>::cast(arguments.body().head()),
                  argument_traits::cast_traits<A01>::cast(arguments.head())
                  );
            };
            static void setup(method& root, F& f) {
               method& target(finder<T01, A01>::find(finder<T00, A00>::find(root)));
               target.function_ = f;
               target.trampoline_ = &reflect::caller;
            };
         };
      };
      template<typename A00, typename A01, typename F>
      bool entry(F& f) {
         trampoline02<F, A00, A01>::reflect<A00, A01>::setup(root_, f);
         trampoline02<F, A00, A01>::reflect<HHH, A01>::setup(root_, f);
         trampoline02<F, A00, A01>::reflect<A00, HHH>::setup(root_, f);
         trampoline02<F, A00, A01>::reflect<HHH, HHH>::setup(root_, f);
         return true;
      };
      // -caller for 3-arg----------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename F, typename A00, typename A01, typename A02>
      struct trampoline03 {
         template<typename T00, typename T01, typename T02>
         struct reflect {
            typedef args<T02, args<T01, args<T00, args<void, void> > > > args_type;
            typedef result_type (*trampoline_type)(holder&, args_type&);
            static result_type caller(holder& function, args_type& arguments) {
               return (*function.unsafe<F>())(
                  argument_traits::cast_traits<A00>::cast(arguments.body().body().head()),
                  argument_traits::cast_traits<A01>::cast(arguments.body().head()),
                  argument_traits::cast_traits<A02>::cast(arguments.head())
                  );
            };
            static void setup(method& root, F& f) {
               method& target(finder<T02, A02>::find(finder<T01, A01>::find(finder<T00, A00>::find(root))));
               target.function_ = f;
               target.trampoline_ = &reflect::caller;
            };
         };
      };
      template<typename A00, typename A01, typename A02, typename F>
      bool entry(F& f) {
         trampoline03<F, A00, A01, A02>::reflect<A00, A01, A02>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<HHH, A01, A02>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<A00, HHH, A02>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<A00, A01, HHH>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<A00, HHH, HHH>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<HHH, A01, HHH>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<HHH, HHH, A02>::setup(root_, f);
         trampoline03<F, A00, A01, A02>::reflect<HHH, HHH, HHH>::setup(root_, f);
         return true;
      };
      // -caller for 4-arg----------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename F, typename A00, typename A01, typename A02, typename A03>
      struct trampoline04 {
         template<typename T00, typename T01, typename T02, typename T03>
         struct reflect {
            typedef args<T03, args<T02, args<T01, args<T00, args<void, void> > > > > args_type;
            typedef result_type (*trampoline_type)(holder&, args_type&);
            static result_type caller(holder& function, args_type& arguments) {
               return (*function.unsafe<F>())(
                  argument_traits::cast_traits<A00>::cast(arguments.body().body().body().head()),
                  argument_traits::cast_traits<A01>::cast(arguments.body().body().head()),
                  argument_traits::cast_traits<A02>::cast(arguments.body().head()),
                  argument_traits::cast_traits<A03>::cast(arguments.head())
                  );
            };
            static void setup(method& root, F& f) {
               method& target(finder<T03, A03>::find(finder<T02, A02>::find(finder<T01, A01>::find(finder<T00, A00>::find(root)))));
               target.function_ = f;
               target.trampoline_ = &reflect::caller;
            };
         };
      };
      template<typename A00, typename A01, typename A02, typename A03, typename F>
      bool entry(F& f) {
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, A01, A02, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, A01, A02, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, HHH, A02, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, A01, HHH, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, A01, A02, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, HHH, A02, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, A01, HHH, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, A01, A02, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, HHH, HHH, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, HHH, A02, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, A01, HHH, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, HHH, HHH, A03>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, HHH, A02, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, A01, HHH, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<A00, HHH, HHH, HHH>::setup(root_, f);
         trampoline04<F, A00, A01, A02, A03>::reflect<HHH, HHH, HHH, HHH>::setup(root_, f);
         return true;
      };
      // -caller for 5-arg----------------------------------------------------------
      // ---------------------------------------------------------------------------
      template<typename F, typename A00, typename A01, typename A02, typename A03, typename A04>
      struct trampoline05 {
         template<typename T00, typename T01, typename T02, typename T03, typename T04>
         struct reflect {
            typedef args<T04, args<T03, args<T02, args<T01, args<T00, args<void, void> > > > > > args_type;
            typedef result_type (*trampoline_type)(holder&, args_type&);
            static result_type caller(holder& function, args_type& arguments) {
               return (*function.unsafe<F>())(
                  argument_traits::cast_traits<A00>::cast(arguments.body().body().body().body().head()),
                  argument_traits::cast_traits<A01>::cast(arguments.body().body().body().head()),
                  argument_traits::cast_traits<A02>::cast(arguments.body().body().head()),
                  argument_traits::cast_traits<A03>::cast(arguments.body().head()),
                  argument_traits::cast_traits<A04>::cast(arguments.head())
                  );
            };
            static void setup(method& root, F& f) {
               method& target(finder<T04, A04>::find(finder<T03, A03>::find(finder<T02, A02>::find(finder<T01, A01>::find(finder<T00, A00>::find(root))))));
               target.function_ = f;
               target.trampoline_ = &reflect::caller;
            };
         };
      };
      template<typename A00, typename A01, typename A02, typename A03, typename A04, typename F>
      bool entry(F& f) {
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, A02, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, A02, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, A02, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, HHH, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, A02, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, A02, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, A02, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, HHH, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, A02, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, A02, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, HHH, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, A02, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, A02, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, HHH, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, HHH, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, A02, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, HHH, A03, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, A02, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, A02, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, HHH, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, HHH, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, A02, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, HHH, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, HHH, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, A02, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, A01, HHH, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, HHH, HHH, A04>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, HHH, A03, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, A02, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, A01, HHH, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<A00, HHH, HHH, HHH, HHH>::setup(root_, f);
         trampoline05<F, A00, A01, A02, A03, A04>::reflect<HHH, HHH, HHH, HHH, HHH>::setup(root_, f);
         return true;
      };
   };
};

#endif
