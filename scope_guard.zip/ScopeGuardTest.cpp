// ScopeGuardTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "boost/guard/scope_guard.hpp"
#include "boost/guard/with_catcher.hpp"
#include "boost/guard/guard_adapter.hpp"
#include "boost/config.hpp"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"

enum { TEST_DURATION = 10 };

#ifdef BOOST_HAS_DECLSPEC
#define DECLSPEC_NOINLINE __declspec(noinline)
#else
#define DECLSPEC_NOINLINE
#endif // BOOST_HAS_DECLSPEC


#if BOOST_WORKAROUND(__BORLANDC__, BOOST_TESTED_AT(0x564))
#pragma option push
#pragma option -vi- // this disables inlining (-vi enables it)
#endif

// Counter function for measuring perfomance
DECLSPEC_NOINLINE void Count(long unsigned* n) {
	++(*n);
}

#if BOOST_WORKAROUND(__BORLANDC__, BOOST_TESTED_AT(0x564))
#pragma option pop
#endif

// Simple exception class
struct my_exception : public std::exception
{
	~my_exception() throw() {}

	const char* what() const throw() {
		return "my_exception";
	}
};

void ExceptionThrower() {
	std::cout << "ExceptionThrower: throwing bad_exception" << std::endl;
	throw my_exception();
}

struct EHandler {
	void operator()(std::exception& e) {
		std::cout << "EHandler: exception has been caught: " << e.what() << std::endl;
	}
};

void ExecGuard(long unsigned* n) {
	BOOST_SCOPE_GUARD(boost::bind(&Count, n));
//	boost::scope_guard guard = boost::make_guard(boost::bind(&Count, n), boost::guard::disarmed);
}

void ExecGuardWException() {
//	boost::scope_guard guard = boost::make_guard(
//		&ExceptionThrower,
//		boost::guard::with_catcher<
//			EHandler,
//			boost::guard::exceptions< std::exception >
//		>(EHandler())
//	);
	boost::scope_guard guard = boost::make_guard(
		&ExceptionThrower,
		boost::guard::catching< std::exception >(EHandler())
	);
}

//////////////////////////////////////////////////////////////////////////
// Test funcs for guard_adapter
//////////////////////////////////////////////////////////////////////////
void foo1() {
	std::cout << "foo1 called" << std::endl;
}
void foo2() {
	std::cout << "foo2 called" << std::endl;
}
void foo3() {
	std::cout << "foo3 called" << std::endl;
}

void undo_foo1() {
	std::cout << "undo_foo1 called" << std::endl;
}
void undo_foo2() {
	std::cout << "undo_foo2 called" << std::endl;
}
void undo_foo3() {
	std::cout << "undo_foo3 called" << std::endl;
}


//////////////////////////////////////////////////////////////////////////
// Guard acquiring policy for CObj objects
//////////////////////////////////////////////////////////////////////////
struct CObjGuardAcq
{
	template< typename IteratorT >
	static boost::guard::enumStatus get_status(IteratorT it) {
		boost::guard_ptr const& p = it->GetGuard();
		if (p)
			return p->get_status();
		else
			return boost::guard::disarmed;
	}
	template< typename IteratorT >
	static void fire(IteratorT it) {
		boost::guard_ptr const& p = it->GetGuard();
		if (p)
			p->fire();
	}
	template< typename IteratorT >
	static void disarm(IteratorT it) {
		boost::guard_ptr const& p = it->GetGuard();
		if (p)
			p->disarm();
	}
	template< typename IteratorT >
	static void arm(IteratorT it) {
		boost::guard_ptr const& p = it->GetGuard();
		if (p)
			p->arm();
	}
};

//////////////////////////////////////////////////////////////////////////
// Test user object that contains guard_ptr
//////////////////////////////////////////////////////////////////////////
class CObj {
	int m_Field;
	boost::guard_ptr m_pDestructingGuard;

public:
	CObj() : m_Field(0) {}
	CObj(int n, boost::scope_guard guard) : m_Field(n), m_pDestructingGuard(guard) {}

	void SetGuard(boost::scope_guard guard) {
		m_pDestructingGuard = guard;
	}

protected:
	//! NOTE: we can't return guard_ptr by value here because we shall lose the owning
	//! of the guard then. This is the guard_ptr distinguishing feature.
	boost::guard_ptr const& GetGuard() const {
		return m_pDestructingGuard;
	}

	friend struct CObjGuardAcq;
};


//////////////////////////////////////////////////////////////////////////
//! The main test
//////////////////////////////////////////////////////////////////////////
int _tmain(int argc, _TCHAR* argv[])
{
	long unsigned Counter = 0;
	time_t Timer;

	// Test perfomance
	std::cout << "Starting direct function call test" << std::endl;
	Timer = time(NULL) + TEST_DURATION;
	while (time(NULL) < Timer)
		Count(&Counter);
	std::cout << "Finished test, " << Counter / ((double)TEST_DURATION * 10e6L) << " millions executions per second" << std::endl;

	std::cout << "Starting leaving scope guard call test" << std::endl;
	Counter = 0;
	Timer = time(NULL) + TEST_DURATION;
	while (time(NULL) < Timer)
		ExecGuard(&Counter);
	std::cout << "Finished test, " << Counter / ((double)TEST_DURATION * 10e6L) << " millions executions per second" << std::endl;

	// Test exception handling
	std::cout << "Starting exception handling test" << std::endl;
	ExecGuardWException();

	// Test actions trace
	std::cout << "Starting guard_adapter tests" << std::endl;
	{
		std::cout << "make_guarded_call, undo guards are stored in stack" << std::endl;
		typedef boost::guard_adapter< std::stack< boost::guard_ptr > > actions_trace;
		actions_trace tracer;
		tracer.push(boost::make_guarded_call(&foo1, &undo_foo1));
		tracer.push(boost::make_guarded_call(&foo2, &undo_foo2));
		tracer.push(boost::make_guarded_call(&foo3, &undo_foo3));
		//tracer.dismiss(); // This line will dismiss all undo_foo functions calling
	}
	{
		std::cout << "make_guarded_call, undo guards are stored in map, ordered by int" << std::endl;
		typedef boost::guard_adapter< std::map< int, boost::guard_ptr > > ordered_guards;
		ordered_guards mg;
		mg[1] = boost::make_guarded_call(&foo1, &undo_foo1);
		mg[3] = boost::make_guarded_call(&foo2, &undo_foo2);
		mg[2] = boost::make_guarded_call(&foo3, &undo_foo3);
	}
	{
		std::cout << "make_guarded_call, guards are stored in list as user object members" << std::endl;
		std::cout << "The undo functions shall be called in forward order instead of backward" << std::endl;
		typedef boost::guard_adapter<
			std::list< CObj >,
			CObjGuardAcq,
			boost::guard::forward_eraser< std::list< CObj >, CObjGuardAcq >
		> guard_list;
		guard_list lg;

		lg.push_back(CObj(1, boost::make_guarded_call(&foo1, &undo_foo1)));
		lg.push_back(CObj(2, boost::make_guarded_call(&foo2, &undo_foo2)));
		lg.push_back(CObj(3, boost::make_guarded_call(&foo3, &undo_foo3)));
	}

	return 0;
}

