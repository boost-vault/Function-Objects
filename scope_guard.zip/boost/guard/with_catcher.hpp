/*!
* \file   with_catcher.hpp
* \author Semashev Andrey
* \date   12.09.2005
* 
* \brief  Scope guard with_catcher invoking policy declaration
*
* \note This policy and other exception-related support is disabled if BOOST_NO_EXCEPTIONS macro defined.
*
* The policy with_catcher allows to call the functor and catch a number of exceptions which may be thrown
* from it. This may be especially useful when the guard is fired while processing another exception.
* In this case the program will end up in std::terminate if the exception thrown by functor is not caught.
* Currently up to 10 exception types can be specified to be caught (this amount is indicated by macro
* BOOST_SCOPE_GUARD_MAX_EXCEPTIONS_SUPPORTED). The following example shows setting up an exception handling
* guard:
*
* <pre>
* scope_guard guard = make_guard(
*    Functor,              // Calling functor
*    guard::with_catcher<  // Invoker policy
*      CHandler,           // This class shall be used to process exceptions caught
*      guard::exceptions< std::bad_cast, std::bad_alloc, CMyException > // Exceptions list
*    >(CHandler())         // A CHandler object
* );
* </pre>
*
* or, the shorter way:
*
* <pre>
* scope_guard guard = make_guard(
*    Functor,
*    guard::catching<
*      std::bad_cast, std::bad_alloc, CMyException
*    >(CHandler())
* );
* </pre>
*
* In this example if any of the specified exceptions is caught, a corresponding operator() of CHandler object
* shall be called to process the exception. That being said, there should be declared functions in CHandler
* class with the following signature:
*
* <pre>
* void operator()(T& e) throw();
* </pre>
*
* where T is every exception type specified in scope guard setup. E.g. CHandler should look something like:
*
* <pre>
* struct CHandler {
*     void operator()(std::bad_cast& e) throw();
*     void operator()(std::bad_alloc& e) throw();
*     void operator()(CMyException& e) throw();
* };
* </pre>
*
* For setting up anonymous catching scope guards the existing set of macroses is extended by BOOST_SCOPE_GUARD_EX,
* BOOST_GUARDED_CALL_EX and BOOST_SG_EXCEPTIONS_n where n may vary from 1 to 10. The first two macroses are
* mere analogues to ones without _EX suffix. The latter is used to enumerate exceptions to be caught and should
* be used with other mentioned two. The example in scope_guard.hpp shows the usage.
*/

#ifndef BOOST_GUARD_WITH_CATCHER_HPP_
#define BOOST_GUARD_WITH_CATCHER_HPP_

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif

// This header is only active when exceptions support is enabled
#ifndef BOOST_NO_EXCEPTIONS

#include <boost/config.hpp>
#include <boost/type_traits/is_pointer.hpp>
#include <boost/preprocessor/repetition.hpp>
#include <boost/preprocessor/arithmetic/add.hpp>
#include <boost/preprocessor/arithmetic/sub.hpp>
#include <boost/guard/unique_name.hpp>

// Macro declares the max number of exceptions that may be specified in with_catcher policy
#define BOOST_SCOPE_GUARD_MAX_EXCEPTIONS_SUPPORTED 10

namespace boost {

namespace guard {

namespace detail {

  //! Empty structs for optional template arguments support
  template< long unsigned > struct nulltype {};

  //! Helper class to invoke exception handler
  template< typename T >
  struct guard_helper {
    template< typename U >
    static void invoke_exception_handler(U& Handler, T& e)
    {
      // If the following line fails to compile then there is
      // an exception type, for which operator() is not defined
      // in exception handler class
      Handler(e);
    }
  };
  template< long unsigned CounterV >
  struct guard_helper< nulltype< CounterV > > {
    template< typename U >
    static void invoke_exception_handler(U&, nulltype< CounterV >&)
    {
    }
  };

} // namespace detail


// Auxiliary macroses for code generation
#define BOOST_SCOPE_GUARD_INTERNAL_TEMPLATE_PARAMS(z, iter, unused)\
  typename BOOST_PP_CAT(ExceptionT, BOOST_PP_ADD(iter, 1)) =\
  detail::nulltype< BOOST_PP_ADD(iter, 1) >
#define BOOST_SCOPE_GUARD_INTERNAL_TYPEDEFS(z, iter, unused)\
  typedef BOOST_PP_CAT(ExceptionT, iter) BOOST_PP_CAT(exception_type, iter);

//! Template class for passing exception types list to with_catcher policy
template<
  typename ExceptionT0,
  BOOST_PP_ENUM(BOOST_PP_SUB(BOOST_SCOPE_GUARD_MAX_EXCEPTIONS_SUPPORTED, 1),
  BOOST_SCOPE_GUARD_INTERNAL_TEMPLATE_PARAMS, ~)
>
struct exceptions
{
  BOOST_PP_REPEAT(
    BOOST_SCOPE_GUARD_MAX_EXCEPTIONS_SUPPORTED,
    BOOST_SCOPE_GUARD_INTERNAL_TYPEDEFS,
    ~
  )
};

#undef BOOST_SCOPE_GUARD_INTERNAL_TYPEDEFS
#undef BOOST_SCOPE_GUARD_INTERNAL_TEMPLATE_PARAMS


#define BOOST_SCOPE_GUARD_INTERNAL_CATCHES(z, iter, unused)\
  catch (BOOST_DEDUCED_TYPENAME BOOST_PP_CAT(ExceptionsListT::exception_type, iter) & e) {\
    typedef detail::guard_helper<\
      BOOST_DEDUCED_TYPENAME BOOST_PP_CAT(ExceptionsListT::exception_type, iter)\
    > Helper_t;\
    Helper_t::invoke_exception_handler(m_Handler, e);\
  }

//! Functor invoking policy with catching specified exceptions
template<
  class EHandlerT,
  class ExceptionsListT
>
class with_catcher : public ExceptionsListT
{
public:
  typedef EHandlerT exceptions_handler_type;

protected:
  //! The exceptions handling object
  mutable exceptions_handler_type m_Handler;

public:
  with_catcher(exceptions_handler_type const& Handler)
    : m_Handler(Handler)
  {
  }

  //! The method invokes the guarded functor
  template< typename FunctorT >
  void fire(FunctorT const& Functor) const {
    try {
      Functor();
    } BOOST_PP_REPEAT(
      BOOST_SCOPE_GUARD_MAX_EXCEPTIONS_SUPPORTED,
      BOOST_SCOPE_GUARD_INTERNAL_CATCHES,
      ~
    )
  }
};

#undef BOOST_SCOPE_GUARD_INTERNAL_CATCHES


//! Functions for creating with_catcher policy object
#define BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS_HEADER(z, iter, unused)\
  BOOST_PP_CAT(typename ExceptionT, BOOST_PP_ADD(iter, 1))

#define BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS(z, iter, unused)\
  BOOST_PP_CAT(ExceptionT, BOOST_PP_ADD(iter, 1))

#define BOOST_SCOPE_GUARD_INTERNAL_CATCHING_FUN(z, iter, unused)\
template<\
  typename ExceptionT0 BOOST_PP_COMMA_IF(iter)\
  BOOST_PP_ENUM(iter, BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS_HEADER, ~),\
  typename HandlerT\
> \
with_catcher<\
  HandlerT,\
  exceptions<\
    ExceptionT0 BOOST_PP_COMMA_IF(iter)\
    BOOST_PP_ENUM(iter, BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS, ~)\
  > \
> catching(HandlerT const& handler) {\
  return with_catcher<\
    HandlerT,\
    exceptions<\
      ExceptionT0 BOOST_PP_COMMA_IF(iter)\
      BOOST_PP_ENUM(iter, BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS, ~)\
    > \
  >(handler);\
}

BOOST_PP_REPEAT(
  BOOST_PP_SUB(BOOST_SCOPE_GUARD_MAX_EXCEPTIONS_SUPPORTED, 1),
  BOOST_SCOPE_GUARD_INTERNAL_CATCHING_FUN,
  ~
)

#undef BOOST_SCOPE_GUARD_INTERNAL_CATCHING_FUN
#undef BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS
#undef BOOST_SCOPE_GUARD_INTERNAL_EXCEPTIONS_HEADER

} // namespace guard

} // namespace boost

//! Macros for creating the anonymous catching guards
#define BOOST_SCOPE_GUARD_EX(functor, exc_type_list, handler) \
  boost::scope_guard BOOST_SG_UNIQUE_NAME(_guard_ex_) =\
    boost::make_guard(\
      functor,\
      boost::guard::catching<\
        exc_type_list\
      >(handler)\
    )

//! Macros for creating the anonymous catching guards with functor invoking
#define BOOST_GUARDED_CALL_EX(enter_functor, leave_functor, exc_type_list, handler) \
  boost::scope_guard BOOST_SG_UNIQUE_NAME(_guard_ex_) =\
    boost::make_guarded_call(\
      enter_functor,\
      leave_functor,\
      boost::guard::catching<\
        exc_type_list\
      >(handler)\
    )

// Macroses for enumerating exceptions to be catched
#define BOOST_SG_EXCEPTIONS_1(exception_type0) exception_type0
#define BOOST_SG_EXCEPTIONS_2(exception_type0, exception_type1)\
  BOOST_SG_EXCEPTIONS_1(exception_type0), exception_type1
#define BOOST_SG_EXCEPTIONS_3(exception_type0, exception_type1, exception_type2)\
  BOOST_SG_EXCEPTIONS_2(exception_type0, exception_type1), exception_type2
#define BOOST_SG_EXCEPTIONS_4(exception_type0, exception_type1, exception_type2, exception_type3)\
  BOOST_SG_EXCEPTIONS_3(exception_type0, exception_type1, exception_type2), exception_type3
#define BOOST_SG_EXCEPTIONS_5(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4)\
  BOOST_SG_EXCEPTIONS_4(exception_type0, exception_type1, exception_type2, exception_type3), exception_type4
#define BOOST_SG_EXCEPTIONS_6(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5)\
  BOOST_SG_EXCEPTIONS_5(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4), exception_type5
#define BOOST_SG_EXCEPTIONS_7(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6)\
  BOOST_SG_EXCEPTIONS_6(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5), exception_type6
#define BOOST_SG_EXCEPTIONS_8(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6, exception_type7)\
  BOOST_SG_EXCEPTIONS_7(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6), exception_type7
#define BOOST_SG_EXCEPTIONS_9(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6, exception_type7, exception_type8)\
  BOOST_SG_EXCEPTIONS_8(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6, exception_type7), exception_type8
#define BOOST_SG_EXCEPTIONS_10(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6, exception_type7, exception_type8, exception_type9)\
  BOOST_SG_EXCEPTIONS_9(exception_type0, exception_type1, exception_type2, exception_type3, exception_type4, exception_type5, exception_type6, exception_type7, exception_type8), exception_type9

#endif // BOOST_NO_EXCEPTIONS

#endif // BOOST_GUARD_WITH_CATCHER_HPP_
