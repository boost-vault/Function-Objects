/*!
 * \file   guard_ptr.hpp
 * \author Semashev Andrey
 * \date   20.09.2005
 * 
 * \brief  Smart guard pointer class definition
 * 
 * The main purpose of the guard_ptr is to provide an ability to store scope guards dynamically, for example
 * in containers. The usage is rather obvious, see the example:
 *
 * <pre>
 * #include <boost/guard/guard_ptr.hpp>
 * #include <boost/guard/guard_adapter.hpp>
 *
 * using namespace boost;
 *
 * typedef guard_adapter< std::stack< guard_ptr > > actions_trace;
 *
 * void SafeFoo() {
 *    // Creating the tracing object
 *    actions_trace tracer;
 *
 *    // Performing cancellable actions
 *    tracer.push(make_guarded_call(&DoSmth1, &UndoSmth1));
 *    tracer.push(make_guarded_call(&DoSmth2, &UndoSmth2));
 *    tracer.push(make_guarded_call(&DoSmth3, &UndoSmth3));
 *
 *    // Checking if everything is ok and commiting changes
 *    if (IsOK())
 *      tracer.dismiss();
 * }
 * </pre>
 *
 * In the example above functions DoSmth1, DoSmth2 and DoSmth3 shall be called consequently, and if the current state
 * is not valid at the end (IsOK returned false), then UndoSmth3, UndoSmth2 and UndoSmth1 shall be called.
 * The same example may be easily expanded for exceptions handling support, see with_catcher.hpp for details.
 *
 * Several notes should be pointed out about guard_ptr:
 * - guard_ptr may be NULL. That is, you should generally check it before use it.
 * - guard_ptr implies exclusive owning semantic. That means there shall be no two guard_ptrs pointing
 *   at the same object. If p1 and p2 are guard_ptrs the expression p1 = p2; means the following:
 *   - If p1 points to an armed scope_guard, the guard shall be deleted (and fired if not disarmed)
 *   - If p2 owns a scope_guard, the owning shall be transferred to p1, otherwise p1 shall be NULL
 *   - p2 shall be released (that is, it shall be NULL after the operation)
 * - guard_ptr provides the ability of assigning the scope_guard objects allocated on the stack.
 *   In this case the copy of the original scope_guard is created and attached to the guard_ptr, and the original
 *   scope guard is disarmed.
 *
 * These rules ensure that the guarded functors shall be called no more than once regardless of number of
 * assignment operations and possible relocations of containers.
 */

#ifndef BOOST_GUARD_PTR_HPP_
#define BOOST_GUARD_PTR_HPP_

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif

#include <boost/guard/scope_guard.hpp>

namespace boost {

//! Simple smart-pointer class to hold scope guard pointers
class guard_ptr
{
private:
  mutable guard::detail::scope_guard_trigger* m_p;

public:
  guard_ptr() : m_p(0) {}
  guard_ptr(guard::detail::scope_guard_trigger const& That) : m_p(That.clone())
  {
    That.disarm();
  }
  guard_ptr(guard_ptr const& p) : m_p(p.release_internal()) {
  }
  ~guard_ptr()
  {
    delete m_p;
  }

  guard::detail::scope_guard_trigger* get() const
  {
    return m_p;
  }
  guard::detail::scope_guard_trigger* release()
  {
    return release_internal();
  }
  guard_ptr& operator= (guard_ptr const& p)
  {
    delete m_p;
    m_p = p.release_internal();
    return *this;
  }
  guard_ptr& operator= (guard::detail::scope_guard_trigger const& That)
  {
    delete m_p;
    m_p = That.clone();
    That.disarm();
    return *this;
  }
  guard::detail::scope_guard_trigger* operator-> () const
  {
    return get();
  }

  operator bool () const
  {
    return (get() != 0);
  }

protected:
  guard::detail::scope_guard_trigger* release_internal() const
  {
    guard::detail::scope_guard_trigger* const p = get();
    m_p = 0;
    return p;
  }
};

} // namespace boost

#endif // BOOST_GUARD_PTR_HPP_
