/*!
 * \file   scope_guard.hpp
 * \author Semashev Andrey
 * \date   25.07.2005
 * 
 * \brief  Generalized scope guard declaration
 * 
 * Generalized scope guard classes are used to perform certain actions at the end of current scope
 * regardless of the way of leaving the scope (while processing an exception, for example).
 *
 * To set a scope guard one must declare the following construction:
 *
 * <pre>
 * scope_guard guard = make_guard(Functor, Invoker);
 * </pre>
 *
 * (NOTE: The namespace specifiers are omitted for simplicity, both scope_guard and make_guard names
 * are declared in boost namespace).
 *
 * In the example above Invoker is a functor to be called at the scope end. It should take no arguments
 * (which may be achieved by boost::bind). The Invoker argument is optional. It denotes the way
 * the functor should be called. By default (if no Invoker parameter provided) the functor shall be simply
 * called with no side actions (this is performed by simple_invoker calling policy).
 *
 * The scope guard object may be armed or disarmed during the processing via arm() and disarm() methods. Only
 * armed scope guards shall fire the functor on their destruction. One may also explicitly fire the guard
 * via fire() method, though it shall not depend on or modify the armed status of the guard.
 *
 * Besidec the make_guard facility there also is make_guarded_call function declared in the file.
 * This function is used instead of make_guard to create similar scope guards which are targeted to undo
 * some actions performed by program in case of some unexpected or undesirable conditions. make_guarded_call
 * accepts one additional functor and executes it immediately. The second functor shall be invoked on the
 * scope guard destruction (in case if it is not disarmed previously). See the example:
 *
 * <pre>
 * scope_guard guard = make_guarded_call(DoFunctor, UndoFunctor, Invoker);
 * </pre>
 *
 * Like the make_guard function, the Invoker argument is optional. This technique is commonly used when
 * performing some discardable actions. See guard_ptr.hpp for an example of implementing discardable actions
 * trace.
 *
 * Besides the described way of setting up scope guards there also are macroses for creating anonymous guards.
 * The following common example shows the usage:
 * 
 * <pre>
 * #include &lt;iostream&gt;
 * #include <boost/guard/scope_guard.hpp>
 * #include <boost/guard/with_catcher.hpp>
 * #include <boost/bind.hpp>
 * 
 * void foo0() {
 *    std::cout << "foo0 called" << std::endl;
 * }
 * 
 * void foo1(int n) {
 *    std::cout << "foo1 called, n = " << n << std::endl;
 * }
 * 
 * struct CMyException {};
 * 
 * struct CExceptionHandler {
 *    void operator()(CMyException& e) throw() {
 *      std::cout << "on_exception called, CMyException caught" << std::endl;
 *    }
 * }
 * 
 * void foo2() throw(CMyException) {
 *    std::cout << "foo2 called, throwing CMyException..." << std::endl;
 *    throw CMyException();
 * }
 * 
 * void test(int x) {
 *    CExceptionHandler Handler;
 *    // Equal to "boost::scope_guard <anonymous> = make_guarded_call(&foo0, boost::bind(&foo1, x));"
 *    BOOST_GUARDED_CALL(&foo0, boost::bind(&foo1, x));
 *    // Equal to "boost::scope_guard <anonymous> = make_guard(&foo2, guard::catching< ... >(Handler));"
 *    BOOST_SCOPE_GUARD_EX(&foo2, SCOPE_GUARD_EXCEPTIONS_1(CMyException), Handler);
 * 
 *    std::cout << "test called, performing some actions..." << std::endl;
 * }
 * </pre>
 * 
 */

#ifndef BOOST_SCOPEGUARD_HPP_
#define BOOST_SCOPEGUARD_HPP_

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif

#include <boost/config.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/guard/unique_name.hpp>

namespace boost {

// Optional forward-declaration of the smart-pointer for guards
#ifndef BOOST_GUARD_PTR_HPP_
class guard_ptr;
#endif

namespace guard {

//! Guard statuses
enum enumStatus {
  //! The enabled scope guard status
  armed = false,
  //! The disabled scope guard status
  disarmed = true
};

//! Direct functor invoking policy
class simple_invoker
{
public:
  //! This function is used to invoke guarded functor
  template< typename FunctorT >
  void fire(FunctorT const& Functor) const {
    Functor();
  }
};

namespace detail {

  //! Base scope guard class
  class scope_guard_trigger
  {
  protected:
    //! Armed status
    mutable enumStatus m_Status;

  public:
    //! Copy constructor
    scope_guard_trigger(scope_guard_trigger const& That)
      : m_Status(That.m_Status)
    {
      That.disarm();
    }
    //! Status initializing constructor
    scope_guard_trigger(enumStatus Status)
      : m_Status(Status)
    {
    }
    //! Destructor
    virtual ~scope_guard_trigger() {}

    //! Explicit functor invoking method
    virtual void fire() const = 0;

    //! Enables the guard
    void arm() const {
      m_Status = armed;
    }
    //! Disables the guard
    void disarm() const {
      m_Status = disarmed;
    }
    //! Returns current guard activity status
    enumStatus get_status() const {
      return m_Status;
    }

  protected:
    //! Object cloning method - specially for guard_ptr
    virtual scope_guard_trigger* clone() const = 0;

    friend class guard_ptr;
  };

  //! Guard of leaving the scope
  template<
    typename FunT,
    typename InvokerT = simple_invoker
  >
  class leaving_scope_guard_impl :
    public scope_guard_trigger,
    public InvokerT
  {
    typedef leaving_scope_guard_impl< FunT, InvokerT > this_type;

  protected:
    typedef scope_guard_trigger trigger_type;

  public:
    typedef InvokerT invoker_type;
    typedef FunT functor_type;

  protected:
    //! Functor to be executed on destruction
    functor_type m_LeavingFunctor;

  private:
    leaving_scope_guard_impl();

  public:
    leaving_scope_guard_impl(
      functor_type const& LeavingFunctor,
      invoker_type const& Invoker = invoker_type(),
      enumStatus Status = armed
    ) :
      trigger_type(Status),
      invoker_type(Invoker),
      m_LeavingFunctor(LeavingFunctor)
    {
    }
    leaving_scope_guard_impl(
      functor_type const& LeavingFunctor,
      enumStatus Status,
      invoker_type const& Invoker = invoker_type()
    ) :
      trigger_type(Status),
      invoker_type(Invoker),
      m_LeavingFunctor(LeavingFunctor)
    {
    }
    ~leaving_scope_guard_impl() {
      if (trigger_type::get_status() == armed)
        leaving_scope_guard_impl::fire();
    }
    void fire() const {
      invoker_type::fire(this->m_LeavingFunctor);
    }

  protected:
    trigger_type* clone() const {
      return new this_type(*this);
    }
  };

} // namespace detail

} // namespace guard

//! Scope guard unified reference type
typedef guard::detail::scope_guard_trigger const& scope_guard;

//! Functions for creating the scope guard
template< typename FunT >
guard::detail::leaving_scope_guard_impl< FunT > make_guard(FunT const& Fun)
{
  typedef guard::detail::leaving_scope_guard_impl< FunT > guard_type;
  return guard_type(Fun);
}
template< typename FunT >
guard::detail::leaving_scope_guard_impl< FunT > make_guard(
  FunT const& Fun, guard::enumStatus Status)
{
  typedef guard::detail::leaving_scope_guard_impl< FunT > guard_type;
  return guard_type(Fun, Status);
}
template< typename FunT, typename InvokerT >
guard::detail::leaving_scope_guard_impl< FunT, InvokerT > make_guard(
  FunT const& Fun,
  InvokerT const& Invoker,
  guard::enumStatus Status = guard::armed
  )
{
  typedef guard::detail::leaving_scope_guard_impl<
    FunT,
    InvokerT
  > guard_type;
  return guard_type(Fun, Invoker, Status);
}

//! Functions for creating the discardable function calls
template< typename FunT1, typename FunT2 >
guard::detail::leaving_scope_guard_impl< FunT2 > make_guarded_call(
  FunT1 const& Action, FunT2 const& Undo)
{
  Action();
  typedef guard::detail::leaving_scope_guard_impl< FunT2 > guard_type;
  return guard_type(Undo);
}
template< typename FunT1, typename FunT2 >
guard::detail::leaving_scope_guard_impl< FunT2 > make_guarded_call(
  FunT1 const& Action, FunT2 const& Undo, guard::enumStatus Status)
{
  if (Status == guard::armed) Action();
  typedef guard::detail::leaving_scope_guard_impl< FunT2 > guard_type;
  return guard_type(Undo, Status);
}
template< typename FunT1, typename FunT2, typename InvokerT >
guard::detail::leaving_scope_guard_impl< FunT2, InvokerT > make_guarded_call(
  FunT1 const& Action,
  FunT2 const& Undo,
  InvokerT const& Invoker,
  guard::enumStatus Status = guard::armed
  )
{
  if (Status == guard::armed) Invoker.fire(Action);
  typedef guard::detail::leaving_scope_guard_impl<
    FunT2,
    InvokerT
  > guard_type;
  return guard_type(Undo, Invoker);
}

} // namespace boost

//! Macros for creating the anonymous guards
#define BOOST_SCOPE_GUARD(functor) \
  boost::scope_guard BOOST_SG_UNIQUE_NAME(_guard_) =\
    boost::make_guard(functor)

//! Macros for creating the anonymous guards with functor invoking
#define BOOST_GUARDED_CALL(enter_functor, leave_functor) \
  boost::scope_guard BOOST_SG_UNIQUE_NAME(_guard_) =\
    boost::make_guarded_call(enter_functor, leave_functor)

#endif // BOOST_SCOPEGUARD_HPP_
