/*!
* \file   unique_name.hpp
* \author Semashev Andrey
* \date   12.09.2005
* 
* \brief  Macroses for generating unique names
*/

#ifndef BOOST_UNIQUE_NAME_HPP_
#define BOOST_UNIQUE_NAME_HPP_

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif

#include <boost/config.hpp>
#include <boost/detail/workaround.hpp>
#include <boost/preprocessor/cat.hpp>

#define BOOST_SG_UNIQUE_NAME_INTERNAL_(prefix, postfix) BOOST_PP_CAT(prefix, postfix)
#define BOOST_SG_UNIQUE_NAME_INTERNAL(prefix, postfix) BOOST_SG_UNIQUE_NAME_INTERNAL_(prefix, postfix)

// In VC 7.0 and later when compiling with /ZI option __LINE__ macro is corrupted
#if BOOST_WORKAROUND(BOOST_MSVC, >=1300)
#  define BOOST_SG_UNIQUE_NAME(prefix) BOOST_SG_UNIQUE_NAME_INTERNAL(prefix, __COUNTER__)
#else
#  define BOOST_SG_UNIQUE_NAME(prefix) BOOST_SG_UNIQUE_NAME_INTERNAL(prefix, __LINE__)
#endif // BOOST_WORKAROUND(BOOST_MSVC, >= 1300)

#endif // BOOST_UNIQUE_NAME_HPP_
