/*!
 * \file   guard_adapter.hpp
 * \author Semashev Andrey
 * \date   20.09.2005
 * 
 * \brief  An adapter class declaration for holding guard_ptrs in containers.
 * 
 * The purpose of guard_adapter class is to ensure the deletion order of elements of the adopted
 * container and redefine some mass-operating facilities for guards in the container. It is assumed
 * that the container holds guard_ptrs. Refer to guard_ptr.hpp for more info.
 *
 * Since the scope guard objects are stored in the container it is often very important to ensure
 * that the elements of the container are destructed in the right order. Unfortunately, the
 * Standard doesn't state the element destruction order. That's where guard_adapter comes in use.
 *
 * The guard_adapter class has the following template parameters:
 *
 * <pre>
 * template<
 *   typename ContainerT,
 *   typename GuardAcquirerT,
 *   typename EraserT
 * >
 * class guard_adapter;
 * </pre>
 *
 * - <b>ContainerT</b>     - The container type to be adopted. This may be sequental, associative container or
 *                           one of the standard container wrappers (stack, queue or priority_queue).
 * - <b>GuardAcquirerT</b> - This is optional template parameter. It is used to acquire guard_ptr objects by
 *                           having an iterator to the container. For example, if ContainerT is
 *                           std::list< guard_ptr > and i is its dereferenceable iterator, then to get guard_ptr
 *                           the expression (*i) is sufficient. In case of std::map it would be i->second. And
 *                           if the container stores some user-defined objects, user must provide his own
 *                           implementation of this policy (in this case GuardAcquirerT becomes mandatory).
 *                           See the implementation of the deref_guard_acq and pair_second_guard_acq for example.
 * - <b>EraserT</b>        - This is optional template parameter. It defines the policy of erasing operations
 *                           order. This includes the container destruction, clear and range erase methods.
 *                           There are three predefined policies: reverse_eraser, forward_eraser and
 *                           container_wrapper_eraser. The first two define the guard fireing order (end-to-begin
 *                           and begin-to-end respectively) and should be used with STL-like containers. The
 *                           latter should be used with standard container wrappers. The default EraserT policy
 *                           for STL-like contaiers will be reverse_eraser, and for wrappers it will be
 *                           container_wrapper_eraser.
 *
 * The adopted container (or wrapper) shall have its original typedefs and methods except non-default
 * constructors (which are not very useful since they imply element copying which may not be desireable
 * due to owning semantic of the guard_ptr). Two new methods shall be added to the container interface:
 *
 * - <i>void dismiss(bool fDismissed = true);</i>
 * The method is used to avoid guard fireing on the container destruction. Note that it does not invoke
 * disarm() method of the guards holded but merely changes the container destruction logic.
 *
 * - <i>bool dismissed() const;</i>
 * The method is used to get the flag weither the dismiss() method was called before for this container.
 *
 * The example of usage of guard_adapter see the guard_ptr.hpp.
 */

#ifndef BOOST_GUARD_ADAPTER_HPP_
#define BOOST_GUARD_ADAPTER_HPP_

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif

#include <queue>
#include <stack>
#include <utility>
#include <boost/guard/scope_guard.hpp>
#include <boost/guard/guard_ptr.hpp>

namespace boost {

namespace guard {

// Guard acquiring policy classes
// The main purpose of these classes is to provide a general access to the guard interface
// having an iterator of a container which points to some object that holds the guard
// or, maybe, is the guard itself.

//! The dereferencing guard acquirer. This policy is used with non-associative containers
struct deref_guard_acq
{
  template< typename IteratorT >
  static enumStatus get_status(IteratorT it) {
    if (it->get())
      return (*it)->get_status();
    else
      return disarmed;
  }
  template< typename IteratorT >
  static void fire(IteratorT it) {
    if (it->get())
      (*it)->fire();
  }
  template< typename IteratorT >
  static void disarm(IteratorT it) {
    if (it->get())
      (*it)->disarm();
  }
  template< typename IteratorT >
  static void arm(IteratorT it) {
    if (it->get())
      (*it)->arm();
  }
};

//! The acquirer for std::pair - second is implied to be the guard_ptr. This policy is used with associative containers
struct pair_second_guard_acq
{
  template< typename IteratorT >
  static enumStatus get_status(IteratorT it) {
    if (it->second.get())
      return it->second->get_status();
    else
      return disarmed;
  }
  template< typename IteratorT >
  static void fire(IteratorT it) {
    if (it->second.get())
      it->second->fire();
  }
  template< typename IteratorT >
  static void disarm(IteratorT it) {
    if (it->second.get())
      it->second->disarm();
  }
  template< typename IteratorT >
  static void arm(IteratorT it) {
    if (it->second.get())
      it->second->arm();
  }
};

namespace detail {
  //! Simple base class for providing the ability of dismissing the guards in container
  class dismissed_flag_holder
  {
  private:
    //! The dismissed flag
    bool m_fDismissed;

  public:
    dismissed_flag_holder() : m_fDismissed(false) {}
    //! The method sets the dismissed flag
    void dismiss(bool fDismissed = true) {
      m_fDismissed = fDismissed;
    }
    //! The method returns the current state of the dismissed flag
    bool dismissed() const {
      return m_fDismissed;
    }
  };
} // namespace detail

//! Erasing policy for end-to-begin deleting order
template< typename ContainerT, typename GuardAcquirerT >
class reverse_eraser :
  public ContainerT,
  public detail::dismissed_flag_holder
{
  typedef GuardAcquirerT guard_acquirer;

public:
  typedef reverse_eraser< ContainerT, GuardAcquirerT > erasing_policy_type;
  typedef ContainerT container_type;

  using container_type::erase;
  //! Overriding erase range method
  void erase(
    BOOST_DEDUCED_TYPENAME container_type::iterator first,
    BOOST_DEDUCED_TYPENAME container_type::iterator last)
  {
    if (last != first) {
      BOOST_DEDUCED_TYPENAME container_type::iterator it = --last;
      for (; it != first; --it) {
        if (guard_acquirer::get_status(it) == armed) {
          guard_acquirer::fire(it);
          guard_acquirer::disarm(it);
        }
      }
      if (guard_acquirer::get_status(it) == armed) {
        guard_acquirer::fire(it);
        guard_acquirer::disarm(it);
      }
      container_type::erase(first, last);
    }
  }

  //! Overriding clear method
  void clear() {
    erase(container_type::begin(), container_type::end());
  }

  ~reverse_eraser() {
    if (!dismissed()) {
      clear();
    } else {
      BOOST_DEDUCED_TYPENAME container_type::iterator it =
        container_type::begin();
      for (; it != container_type::end(); ++it) {
        guard_acquirer::disarm(it);
      }
    }
  }
};

//! Erasing policy for begin-to-end deleting order
template< typename ContainerT, typename GuardAcquirerT >
class forward_eraser :
  public ContainerT,
  public detail::dismissed_flag_holder
{
  typedef GuardAcquirerT guard_acquirer;

public:
  typedef forward_eraser< ContainerT, GuardAcquirerT > erasing_policy_type;
  typedef ContainerT container_type;

  using container_type::erase;
  //! Overriding erase range method
  void erase(
    BOOST_DEDUCED_TYPENAME container_type::iterator first,
    BOOST_DEDUCED_TYPENAME container_type::iterator last)
  {
    BOOST_DEDUCED_TYPENAME container_type::iterator it = first;
    for (; it != last; ++it) {
      if (guard_acquirer::get_status(it) == armed) {
        guard_acquirer::fire(it);
        guard_acquirer::disarm(it);
      }
    }
    container_type::erase(first, last);
  }

  //! Overriding clear method
  void clear() {
    erase(container_type::begin(), container_type::end());
  }

  ~forward_eraser() {
    if (!dismissed()) {
      clear();
    } else {
      BOOST_DEDUCED_TYPENAME container_type::iterator it =
        container_type::begin();
      for (; it != container_type::end(); ++it) {
        guard_acquirer::disarm(it);
      }
    }
  }
};

//! Erasing policy for container wrappers stack, queue and priority_queue
template< typename WrapperT >
class container_wrapper_eraser :
  public WrapperT,
  public detail::dismissed_flag_holder
{
public:
  typedef container_wrapper_eraser< WrapperT > erasing_policy_type;
  typedef WrapperT container_type;

  ~container_wrapper_eraser() {
    if (dismissed()) {
      while (!container_type::empty()) {
        if (container_type::top().get())
          container_type::top()->disarm();
        container_type::pop();
      }
    } else {
      while (!container_type::empty())
        container_type::pop();
    }
  }
};

/*!
 * \brief Template for auto-detecting the default erasing policy
 *
 * The default policy shall be reverse_eraser except the cases
 * when ContainerT is one of the known wrappers: stack, queue or priority_queue.
 * For these wrappers container_wrapper_eraser shall be used.
*/
template< typename ContainerT, typename GuardAcquirerT >
class default_erasing_policy :
  public reverse_eraser< ContainerT, GuardAcquirerT >
{
};
template< typename T, typename NativeContainerT, typename GuardAcquirerT >
class default_erasing_policy< std::stack< T, NativeContainerT >, GuardAcquirerT > :
  public container_wrapper_eraser< std::stack< T, NativeContainerT > >
{
};
template< typename T, typename NativeContainerT, typename GuardAcquirerT >
class default_erasing_policy< std::queue< T, NativeContainerT >, GuardAcquirerT > :
  public container_wrapper_eraser< std::queue< T, NativeContainerT > >
{
};
template< typename T, typename NativeContainerT, typename GuardAcquirerT >
class default_erasing_policy< std::priority_queue< T, NativeContainerT >, GuardAcquirerT > :
  public container_wrapper_eraser< std::priority_queue< T, NativeContainerT > >
{
};

namespace detail {

  //! Helper class to actually detect the type of elements in the container
  template< typename T >
  class default_acquiring_policy_helper;

  template< >
  class default_acquiring_policy_helper< guard_ptr > :
    public deref_guard_acq
  {
  };

  template< typename KeyT >
  class default_acquiring_policy_helper< std::pair< KeyT, guard_ptr > > :
    public pair_second_guard_acq
  {
  };

} // namespace detail

/*!
 * \brief Template for auto-detecting the default guard acquiring policy
 *
 * The policy deref_guard_acq shall be used for non-associative containers that
 * hold guard_ptrs as its elements. The pair_second_guard_acq policy shall be used
 * for associative containers that hold guard_ptrs as mapped values (that are
 * accessible as second part of pair-elements of the container). Otherwise
 * the auto-detection algorithm shall fail to determine the policy, so the user
 * will have to explicitly provide his own one.
*/
template< typename ContainerT >
class default_acquiring_policy :
  public detail::default_acquiring_policy_helper< typename ContainerT::value_type >
{
};

} // namespace guard

//! Guard container adapter class
template<
  typename ContainerT,
  typename GuardAcquirerT = guard::default_acquiring_policy< ContainerT >,
  typename EraserT = guard::default_erasing_policy< ContainerT, GuardAcquirerT >
>
class guard_adapter :
  public EraserT
{
};

} // namespace boost

#endif // BOOST_GUARD_ADAPTER_HPP_
