#ifndef BOOST_EGG_COPY_HPP
#define BOOST_EGG_COPY_HPP
#include <boost/egg/detail/prefix.hpp>


// Boost.Egg
//
// Copyright Shunsuke Sogame 2007-2008.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)


// What:
//
// Same as 'boost::implicit_cast<NonReference>'.
// As the target is not reference, this can detect
// loss of range when a numeric type is converted.


#include <boost/mpl/and.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/or.hpp>
#include <boost/numeric/conversion/cast.hpp> // numeric_cast
#include <boost/type_traits/is_floating_point.hpp>
#include <boost/type_traits/is_integral.hpp>
#include <boost/type_traits/is_reference.hpp>
#include <boost/egg/by_cref.hpp>
#include <boost/egg/detail/adl_barrier.hpp>


namespace boost { namespace egg {


    namespace copy_detail {


        template<class T>
        struct is_numeric :
            mpl::or_<
                is_floating_point<T>,
                is_integral<T>
            >
        { };


        template<class To>
        struct little
        {
            template<class Me, class From>
            struct apply
            {
                typedef To type;
            };

            template<class Re, class From>
            To call(From &from) const
            {
                BOOST_MPL_ASSERT_NOT((is_reference<To>));
                return aux_(from, mpl::and_< is_numeric<To>, is_numeric<From> >());
            }

            template<class From>
            To aux_(From &from, mpl::true_) const
            {
#if !defined(NDEBUG)
                return boost::numeric_cast<To>(from);
#else
                return static_cast<To>(from); // suppress "loss of data" warning.
#endif
            }

            template<class From>
            To aux_(From &from, mpl::false_) const
            {
                return from;
            }
        };


    } // namespace copy_detail


    template<class To>
    struct X_copy :
        function<copy_detail::little<To>, by_cref>
    { };


BOOST_EGG_ADL_BARRIER(copy) { // for std
    template<class To, class From> inline
    To copy(From const &from)
    {
        return X_copy<To>()(from);
    }
}


} } // namespace boost::egg


#include <boost/egg/detail/suffix.hpp>
#endif
