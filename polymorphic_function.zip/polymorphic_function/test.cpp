//  Polymorphic function test

//  Copyright Daniel Walker 2008. Use, modification and
//  distribution is subject to the Boost Software License, Version
//  1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

#include "polymorphic_function.hpp"

#include <cassert>
#include <functional>

#include <boost/mpl/assert.hpp>
#include <boost/mpl/placeholders.hpp>
#include <boost/mpl/void.hpp>
#include <boost/ref.hpp>
#include <boost/type_traits/is_same.hpp>

// Deducing the return type for nullary calls of polymorphic
// functors requires C++0x result_of which is available on Boost
// trunk for platforms with decltype.
#ifdef POLYMORPHIC_FUNCTION_CPP0X
#  define TEST_NULLARY_FUNCTORS
#endif

typedef int(*callable_type)(int);

int builtin() { return 1; }
int builtin(int i) { return i; }
int builtin(int i, int) { return i; }
int builtin(int i, int, int) { return i; }

struct functor {
    template<class> struct result;

    double operator()() { return .1; }

    template<class F, class T>
    struct result<F(T)> { typedef T type;};
    template<class T>
    T operator()(T t) const { return t; }

    template<class F, class T0, class T1>
    struct result<F(T0,T1)> { typedef T0 type;};
    template<class T0, class T1>
    T0 operator()(T0 t, T1) const { return t; }

    template<class F, class T0, class T1, class T2>
    struct result<F(T0,T1,T2)> { typedef T0 type;};
    template<class T0, class T1, class T2>
    T0 operator()(T0 t, T1, T2) const { return t; }
};

typedef int(*call_by_reference_type)(int &);

struct call_by_reference {
    typedef void result_type;
    template<class T>
    void operator()(T & t) const { t = 1;}
};

int main()
{
    using namespace boost::mpl::placeholders;
    using boost::mpl::void_;

    using boost::functional::signature;
    using boost::functional::call_signature;
    using boost::functional::erase;
    using boost::functional::is_polymorphic_function;
    using boost::functional::is_incomplete_function;
    using boost::functional::argument_of;
    using boost::functional::polymorphic_function;
    using boost::functional::functional_cast;

    int zero = 0, one = 1;
    double point_one = .1;

    //  Erasing callable object types
    {
        BOOST_MPL_ASSERT((
            boost::is_same<
                erase<callable_type(int)>::type
              , int(int)
            >
        ));
        BOOST_MPL_ASSERT((
            boost::is_same<
                erase<functor(int)>::type
              , int(int)
            >
        ));
        BOOST_MPL_ASSERT((
            boost::is_same<
                erase<functor(_1)>::type
              , void_
            >
        ));
    }

    // Detecting polymorphic signatures
    {
        BOOST_MPL_ASSERT((
            is_polymorphic_function<
                functor(_1)
            >
        ));
        BOOST_MPL_ASSERT((
            is_polymorphic_function<
                functor(int, int, _1)
            >
        ));
        BOOST_MPL_ASSERT((
            is_polymorphic_function<
                signature<functor(int)>
            >
        ));
        BOOST_MPL_ASSERT_NOT((
            is_polymorphic_function<
                void()
            >
        ));
        BOOST_MPL_ASSERT_NOT((
            is_polymorphic_function<
                int(int, int, int)
            >
        ));
        BOOST_MPL_ASSERT_NOT((
            is_polymorphic_function<
                call_signature<functor(_1)>
            >
        ));
    }

    // Detecting incomplete polymorphic signatures
    {
        BOOST_MPL_ASSERT((
            is_incomplete_function<
                functor(_1)
            >
        ));
        BOOST_MPL_ASSERT((
            is_incomplete_function<
                functor(int, int, _1)
            >
        ));
        BOOST_MPL_ASSERT_NOT((
            is_incomplete_function<
                functor()
            >
        ));
        BOOST_MPL_ASSERT_NOT((
            is_incomplete_function<
                functor(int)
            >
        ));
    }

    // Deducing argument types
    {
        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of< callable_type(long), 0 >::type
              , int
            >
        ));
        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of< callable_type(_1), 0 >::type
              , void_
            >
        ));
        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of< call_by_reference_type(int), 0 >::type
              , int &
            >
        ));
    }
    {
        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of< functor(int, long, int), 1>::type
              , long
            >
        ));
        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of< functor(_1), 0 >::type
              , void_
            >
        ));
#ifdef POLYMORPHIC_FUNCTION_CPP0X
        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of< call_by_reference(int), 0>::type
              , int &
            >
        ));
#endif
    }

    // Call wrapping using call signatures
    {
        polymorphic_function<
            int(int)
        > f = builtin;
        assert(f(one)/2 == 0);
        f = functor();
        assert(f(one)/2 == 0);
    }
    {
        polymorphic_function<
            call_signature<int(int)>
        > f = builtin;
        assert(f(one)/2 == 0);
        f = functor();
        assert(f(one)/2 == 0);
    }

    // Call wrapping using polymorphic signatures
    {
        polymorphic_function<
            functor(_1)
        > f = functor();
        assert(f(one)/2 == 0);
        assert(f(point_one)/2 == .05);
    }
    {
        polymorphic_function<
            signature<functor(_1)>
        > f = functor();
        assert(f(one)/2 == 0);
        assert(f(point_one)/2 == .05);
    }
    {
        polymorphic_function<
            signature<functor(int)>
        > f = functor();
        assert(f(one)/2 == 0);
        assert(f(point_one)/2 == 0);
    }
    {
        polymorphic_function<
            signature<callable_type(int)>
        > f = builtin;
        assert(f(one)/2 == 0);
    }
    {
        polymorphic_function<
            signature<call_by_reference(int&)>
        > f = call_by_reference();
        int x = 0;
        f(x);
        assert(x == 1);
    }
#ifdef POLYMORPHIC_FUNCTION_CPP0X
    {
        polymorphic_function<
            call_by_reference(_1)
        > f = call_by_reference();
        int x = 0;
        f(x);
        assert(x == 1);
    }
#endif

    // Nary call wrapping
    {
        polymorphic_function<
            int()
        > f0 = builtin;
        assert(f0()/2 == 0);
        polymorphic_function<
            int(int)
        > f1 = builtin;
        assert(f1(one)/2 == 0);
        polymorphic_function<
            int(int, int)
        > f2 = builtin;
        assert(f2(one,zero)/2 == 0);
        polymorphic_function<
            int(int, int, int)
        > f3 = builtin;
        assert(f3(one,zero,zero)/2 == 0);

        f0 = functor();
        assert(f0()/2 == 0);
        f1 = functor();
        assert(f1(one)/2 == 0);
        f2 = functor();
        assert(f2(one,zero)/2 == 0);
        f3 = functor();
        assert(f3(one,zero,zero)/2 == 0);
    }
    {
#ifdef TEST_NULLARY_FUNCTORS
        polymorphic_function<
            signature<functor()>
        > f0 = functor();
        assert(f0()/2 == .05);
#endif
        polymorphic_function<
            signature<functor(double)>
        > f1 = functor();
        assert(f1(one)/2 == .5);
        polymorphic_function<
            signature<functor(double, int)>
        > f2 = functor();
        assert(f2(one,zero)/2 == .5);
        polymorphic_function<
            signature<functor(double, int, int)>
        > f3 = functor();
        assert(f3(one,zero,zero)/2 == .5);
    }
    {
#ifdef TEST_NULLARY_FUNCTORS
        polymorphic_function<
            signature<functor()>
        > f0 = functor();
        assert(f0()/2 == .05);
#endif
        polymorphic_function<
            functor(_1)
        > f1 = functor();
        assert(f1(point_one)/2 == .05);
        polymorphic_function<
            functor(_1, _2)
        > f2 = functor();
        assert(f2(point_one,zero)/2 == .05);
        polymorphic_function<
            functor(_1, _2, _2)
        > f3 = functor();
        assert(f3(point_one,zero,zero)/2 == .05);
    }

    // Casting function wrappers
    {
        polymorphic_function<int(int)> f
            = functional_cast<int(int)>(builtin);
        assert(f(one)/2 == 0);

        polymorphic_function<signature<callable_type(int)> > g
            = functional_cast<signature<callable_type(int)> >(builtin);
        assert(g(one)/2 == 0);

        polymorphic_function<double(double)> h
            = functional_cast<double(double)>(g);
        assert(h(one)/2 == .5);
    }
    {
        polymorphic_function<int(int)> f
            = functional_cast<int(int)>(functor());
        assert(f(one)/2 == 0);

        polymorphic_function<signature<functor(int)> > g
            = functional_cast<signature<functor(int)> >(functor());
        assert(g(one)/2 == 0);

        assert(functional_cast<functor(_1)>(g)(one)/2 == 0);
        assert(functional_cast<functor(_1)>(g)(point_one)/2 == .05);
        assert(functional_cast<functor(_1, _2)>(g)(point_one, zero)/2 == .05);

        polymorphic_function<double(double)> h
            = functional_cast<double(double)>(g);
        assert(h(one)/2 == .5);

        assert(functional_cast<functor(_1)>(h)(one)/2 == 0);
        assert(functional_cast<functor(_1)>(h)(point_one)/2 == .05);
        assert(functional_cast<functor(_1, _2)>(h)(point_one, zero)/2 == .05);
    }
    {
#ifdef POLYMORPHIC_FUNCTION_CPP0X
        using std::function;
#else
        using boost::function;
#endif
        function<int(int)> f = functor();
        assert(f(one)/2 == 0);

        function<double(double)> g
            = functional_cast<double(double)>(f);
        assert(g(one)/2 == .5);

        function<double(double,double)> h
            = functional_cast<signature<functor(double,double)> >(f);
        assert(h(one, zero)/2 == .5);
    }

    // Using reference wrapped functors
    {
#ifdef POLYMORPHIC_FUNCTION_CPP0X
        using std::reference_wrapper;
        using std::cref;
#else
        using boost::reference_wrapper;
        using boost::cref;
#endif
        BOOST_MPL_ASSERT((
            boost::is_same<
                erase<
                    reference_wrapper<const functor>(int)
                >::type
              , int(int)
            >
        ));

        BOOST_MPL_ASSERT((
            is_polymorphic_function<
                reference_wrapper<const functor>(_1)
            >
        ));

        BOOST_MPL_ASSERT((
            is_incomplete_function<
                reference_wrapper<const functor>(_1)
            >
        ));

        BOOST_MPL_ASSERT((
            boost::is_same<
                argument_of<
                    reference_wrapper<const functor>(int, long, int)
                  , 1
                >::type
              , long
            >
        ));

        polymorphic_function<
            reference_wrapper<const functor>(_1)
        > f = cref(functor());
        assert(f(one)/2 == 0);
        assert(f(point_one)/2 == .05);

        polymorphic_function<
            const functor(_1)
        > g = functional_cast<const functor(_1)>(f);
        assert(g(one)/2 == 0);
        assert(g(point_one)/2 == .05);

        polymorphic_function<
            reference_wrapper<const functor>(_1)
        > h = functional_cast<reference_wrapper<const functor>(_1)>(g);
        assert(h(one)/2 == 0);
        assert(h(point_one)/2 == .05);
    }
}
