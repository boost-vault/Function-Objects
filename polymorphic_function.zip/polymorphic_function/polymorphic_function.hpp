//  Polymorphic function

//  Copyright Daniel Walker 2008. Use, modification and
//  distribution is subject to the Boost Software License, Version
//  1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

#ifndef POLYMORPHIC_FUNCTION_HPP
#define POLYMORPHIC_FUNCTION_HPP

#include <boost/config.hpp>

// The emerging C++0x standard is cited several times below. As of the
// time of writing, the latest draft of the standard is N2606:
// http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2008/n2606.pdf

// Define POLYMORPHIC_FUNCTION_CPP0X to make use of
// new c++0x features when available.
#if defined(BOOST_HAS_RVALUE_REFS) && defined(BOOST_HAS_DECLTYPE)
#   define POLYMORPHIC_FUNCTION_CPP0X
#endif

// Maximum function arity may be configured by defining
// POLYMORPHIC_FUNCTION_MAX_ARITY, which defaults to Boost.MPL's arity
// limit.
#if !defined(POLYMORPHIC_FUNCTION_MAX_ARITY)
#   include <boost/mpl/limits/arity.hpp>
#   define POLYMORPHIC_FUNCTION_MAX_ARITY BOOST_MPL_LIMIT_METAFUNCTION_ARITY
#endif

#include <functional>
#include <typeinfo>

#include <boost/function.hpp>
#include <boost/function_types/components.hpp>
#include <boost/function_types/parameter_types.hpp>
#include <boost/function_types/function_type.hpp>
#include <boost/function_types/is_callable_builtin.hpp>
#include <boost/mpl/at.hpp>
#include <boost/mpl/identity.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/end.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/find_if.hpp>
#include <boost/mpl/front.hpp>
#include <boost/mpl/is_placeholder.hpp>
#include <boost/mpl/pop_front.hpp>
#include <boost/mpl/push_front.hpp>
#include <boost/mpl/transform.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/control/if.hpp> 
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_trailing_params.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/repetition/repeat_from_to.hpp>
#include <boost/preprocessor/tuple/rem.hpp>
#include <boost/ref.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/add_pointer.hpp>
#include <boost/type_traits/remove_reference.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/utility/result_of.hpp>

namespace boost {

// Until polymorphic_function finds a permanent home, put it in
// namespace functional.
namespace functional {

// Forward declare substitutes and traits classes.
template<class Signature> struct signature;
template<class Signature> struct call_signature;
template<class Signature> struct erase;
template<class Signature> struct is_polymorphic_function;
template<class Signature> struct is_incomplete_function;
template<class Signature, long i> struct argument_of;

namespace detail {

// Forward declare internal traits classes.
template<class Signature> struct call_erasure_type;
template<class Signature> struct functor_type;
template<class Signature> struct components;
template<class Signature> struct callable_object_type;
template<class Signature> struct parameter_types;
template<class Signature> struct is_reference_wrapped_callable_object;

// Choose Boost implementations of standard library components if
// possible and import them and some other related utilities into
// namespace detail::std_.
namespace std_ {

using ::boost::mpl::identity;
using ::boost::is_same;
using ::boost::add_pointer;
using ::boost::remove_reference;

#if defined(POLYMORPHIC_FUNCTION_CPP0X)

using ::boost::result_of;
using ::std::function;
using ::std::reference_wrapper;
using ::std::forward;

template<class T>
struct unwrap_reference
    : detail::std_::identity<T> {
};

template<class T>
struct unwrap_reference< ::std::reference_wrapper<T> >
    : detail::std_::identity<T> {
};

template<class T>
struct is_reference_wrapper
    : mpl::false_ {
};

template<class T>
struct is_reference_wrapper< ::std::reference_wrapper<T> >
    : mpl::true_ {
};

#else // defined(POLYMORPHIC_FUNCTION_CPP0X)

using ::boost::function;
using ::boost::reference_wrapper;
using ::boost::unwrap_reference;
using ::boost::is_reference_wrapper;

// Make result_of work with boost::reference_wrapped callable objects.
template<class Signature>
struct workaround_result_of_reference_wrapper_issue
    : function_types::function_type<
          typename mpl::push_front<
              typename mpl::pop_front<
                  detail::components<Signature>
              >::type
            , typename detail::callable_object_type<Signature>::type
          >::type
      > {
};

// Make result_of deduce non-reference argument types when passed references.
template<class Signature>
struct workaround_result_of_argument_reference_issue
    : function_types::function_type<
          typename mpl::push_front<
              typename mpl::transform<
                  detail::parameter_types<Signature>
                , detail::std_::remove_reference<mpl::placeholders::_1>
              >::type
            , typename mpl::front<
                  detail::components<Signature>
              >::type
          >::type
      > {
};

template<class Signature>
struct result_of
    : ::boost::result_of<
          typename workaround_result_of_reference_wrapper_issue<
              typename workaround_result_of_argument_reference_issue<
                  Signature
              >::type
          >::type
      > {
};

#endif // defined(POLYMORPHIC_FUNCTION_CPP0X)

template<typename F>
typename detail::std_::unwrap_reference<F>::type &
unwrap(F & f)
{
    return f;
}

template<bool B, class T = void>
struct enable_if : ::boost::enable_if_c<B,T> {
};

template<bool B, class T = detail::std_::identity<void> >
struct lazy_enable_if : ::boost::lazy_enable_if_c<B,T> {
};

} // namespace std_

// A few simple, auxiliary traits classes to facilitate
// classification, decomposition, and synthesis of polymorphic
// functions.
template<class Signature>
struct call_erasure_type
    : detail::std_::identity<
          detail::std_::function<
              typename erase<Signature>::type
          >
      > {
};

template<class Signature>
struct functor_type
    : mpl::eval_if<
          function_types::is_callable_builtin<
              typename mpl::front<detail::components<Signature> >::type
          >
        , detail::call_erasure_type<Signature>
        , mpl::front<detail::components<Signature> >
      > {
};

template<class Signature>
struct components
    : function_types::components<
          typename signature<Signature>::type
      > {
};

template<class Signature>
struct callable_object_type
    : detail::std_::unwrap_reference<
          typename mpl::front<detail::components<Signature> >::type
      > {
};

template<class Signature>
struct parameter_types
    : function_types::parameter_types<
          typename signature<Signature>::type
      > {
};

template<class Signature>
struct is_reference_wrapped_callable_object
    : detail::std_::is_reference_wrapper<
          typename mpl::front<detail::components<Signature> >::type
      > {
};

} // namespace detail

//////////////////////////////////////////////////////////////////////
// Signature protocols
//////////////////////////////////////////////////////////////////////

// C++ postfix-expression (5.2.2) used to define signatures.
#define SIGNATURE_EXPRESSION(n, x) \
   x ( BOOST_PP_ENUM_PARAMS(n, x) ) \
 /**/

// Substitute template used to request the polymorphic signature
// protocol for interpreting signature expressions as:
//            Funtor(Forward0, Forward1, ..., ForwardN)
// where:
//     * Functor is a callable object (20.5.1.4) or reference wrapped
//       (20.5.5) callable object.
//     * Forward0, Forward1, ..., ForwardN are either Boost.MPL
//       placeholders or the target types for forwarding each
//       corresponding function argument.
// Note: A polymorphic signature is said to be "incomplete" if any
// of Forward0, Forward1, ..., ForwardN are Boost.MPL placeholders.
template<class Signature>
struct signature
    : detail::std_::identity<Signature> {
};

template<class Signature>
struct signature<signature<Signature> >
    : detail::std_::identity<Signature> {
};

// Substitute template used to request the call signature
// (20.5.1.2) protocol.
template<class Signature>
struct call_signature
    : detail::std_::identity<Signature> {
};

template<class Signature>
struct call_signature<call_signature<Signature> >
    : detail::std_::identity<Signature> {
};

// Given a polymorphic signature, the erase<> metafunction returns the
// corresponding call signature. In effect, it converts a polymorphic
// signature to a call signature, thereby erasing the type of the
// polymorphic signature's callable object. If the polymorphic
// signature contains unspecified arguments (i.e. placeholders), erase
// return boost::mpl::void_.
template<class Signature>
struct erase
    : mpl::eval_if<
          is_incomplete_function<Signature>
        , mpl::void_
        , function_types::function_type<
              mpl::push_front<
                  mpl::pop_front<
                      detail::components<Signature>
                  >
                , typename detail::std_::result_of<
                      typename signature<Signature>::type
                  >::type
              >
          >
      > {
};

//////////////////////////////////////////////////////////////////////
// Traits classes
//////////////////////////////////////////////////////////////////////

// is_polymorphic_function detects the polymorphic signature protocol
// for describing rank-n function objects.
template<class Signature>
struct is_polymorphic_function
    : is_incomplete_function<Signature> {
};

template<class Signature>
struct is_polymorphic_function<signature<Signature> >
    : mpl::true_ {
};

// Given a polymorphic signature, if some of the argument types are
// unspecified (i.e. if they are placeholders), the function is
// incomplete.
template<class Signature>
struct is_incomplete_function
    : mpl::not_< detail::std_::is_same<
          typename mpl::find_if<
              detail::parameter_types<Signature>
            , mpl::is_placeholder<mpl::_1>
          >::type
        , typename mpl::end<
              detail::parameter_types<Signature>
          >::type
      > > {
};

// Given a polymorphic signature and an index, argument_of deduces the
// type of the argument taken by the callable object at the index. For
// example, if the signature specifies that the first argument passed
// to f is int, and f takes its first argument by reference, then
// argument_of<f(int)>::type is int&. If the signature is incomplete or
// if the index is out of bounds, argument_of returns
// boost::mpl::void_. Argument deduction works for builtin functions
// on C++98 and C++0x. Argument deduction for function objects
// requires C++0x decltype. On compilers without decltype, when
// deducing arguments of function objects, argument_of simply echos
// the type at the given index of the argument list in the signature.
template<class Signature, long i>
class argument_of {
    template<class S, long j> struct deduced_argument;
    template<class S> struct builtin_parameters;
    template<class S> struct functor_parameters;
public:
    typedef typename mpl::eval_if<
        is_incomplete_function<Signature>
      , mpl::void_
      , deduced_argument<Signature, i>
    >::type type;

private:
    template<class S, long j>
    struct deduced_argument
        : mpl::at_c<
              typename mpl::if_<
                  function_types::is_callable_builtin<
                      typename detail::callable_object_type<S>::type
                  >
                , builtin_parameters<S>
                , functor_parameters<S>
              >::type
            , j
        > {
    };

    template<class S>
    struct builtin_parameters
        : function_types::parameter_types<
              typename detail::callable_object_type<S>::type
          > {
    };

#if defined(POLYMORPHIC_FUNCTION_CPP0X)

    // The demote<> metafunction supports argument_of in deducing the
    // argument types of function objects on compilers with
    // decltype. In effect, it demotes first class function objects to
    // second class by deducing the member function pointer type of
    // operator().
    template<class S> class demote;

#   define DEMOTE_BOILERPLATE(z, n, _) \
      template<class S, BOOST_PP_ENUM_PARAMS(n, class S)> \
      class demote<SIGNATURE_EXPRESSION(n, S)> { \
          typedef typename detail::callable_object_type< \
              SIGNATURE_EXPRESSION(n, S) \
          >::type callable_type; \
          template<class P> \
          static P deduce_pointer(P p) { return p; } \
      public: \
          typedef decltype( \
              deduce_pointer( \
                  &callable_type::template operator()< \
                      BOOST_PP_ENUM_PARAMS(n, S) \
                  > \
              ) \
          ) type; \
      }; \
    /**/

    BOOST_PP_REPEAT_FROM_TO(
        1
      , BOOST_PP_INC(POLYMORPHIC_FUNCTION_MAX_ARITY)
      , DEMOTE_BOILERPLATE
      , _
    )

#   undef DEMOTE_BOILERPLATE

    template<class S>
    struct functor_parameters
        : mpl::pop_front<
              function_types::parameter_types<
                  typename demote<S>::type
              >
          >::type {
    };

#else // defined(POLYMORPHIC_FUNCTION_CPP0X)

    template<class S>
    struct functor_parameters
        : detail::parameter_types<S> {
    };

#endif // defined(POLYMORPHIC_FUNCTION_CPP0X)
};

//////////////////////////////////////////////////////////////////////
// Polymorphic call wrappers
//////////////////////////////////////////////////////////////////////

// polymorphic_function is a call wrapper used to defer invocations of
// arbitrary callable objects. (20.5.1) polymorphic_function may be
// instantiated with either signature protocol for describing callable
// objects. If instantiated with a call signature, it performs
// type-erasure and behaves like std::function (20.5.15). If
// instantiated with a polymorphic signature, it supports argument
// dependent return types. Either signature protocol may be used to
// defer builtin functions thereby promoting them to first class.
template<class Signature, bool Poly = is_polymorphic_function<Signature>::value>
class polymorphic_function;

#define CALL_WRAPPER_BOILERPLATE( \
             n \
           , is_polymorphic \
           , signature \
           , function_object \
           , initializer \
           , dispatcher \
           , accessor \
           , tr1_result \
         ) \
   template< class T BOOST_PP_ENUM_TRAILING_PARAMS(n, class T) > \
   class polymorphic_function< signature(n, T), is_polymorphic > { \
       typedef function_object(n) function_type; \
   public: \
       tr1_result(n) \
       explicit polymorphic_function() \
       { \
       } \
       template<class G> \
       polymorphic_function(G g) \
           : f(g) \
       { \
       } \
       initializer(n) \
       dispatcher(n, ) \
       dispatcher(n, const) \
       accessor(n, ) \
       accessor(n, const) \
   private: \
       function_type f; \
   }; \
 /**/

// Call signature protocol

#define CALL_SIGNATURE(n, x) \
   call_signature< SIGNATURE_EXPRESSION(n, x) > \
 /**/

#define RANK_1_FUNCTION_OBJECT(n) \
   detail::std_::function< SIGNATURE_EXPRESSION(n, T) >
 /**/

#define RANK_1_INITIALIZER(n) \
   polymorphic_function( \
       typename detail::std_::add_pointer< \
           SIGNATURE_EXPRESSION(n, T) \
       >::type g \
   ) \
       : f(g) \
   { \
   } \
 /**/

#define RANK_1_DISPATCHER(n, cv_qualification) \
   T operator()( BOOST_PP_ENUM_BINARY_PARAMS(n, T, t) ) cv_qualification \
   { \
       return f( BOOST_PP_ENUM_PARAMS(n, t) ); \
   } \
 /**/

#define RANK_1_ACCESSOR(n, cv_qualification) \
   template <class S> \
   cv_qualification S* target() cv_qualification \
   { \
       return f.target<S>(); \
   } \
/**/

#define RANK_1_RESULT_TYPE(n) \
   typedef T result_type; \
 /**/

#define RANK_1_CALL_WRAPPER(n, signature) \
   CALL_WRAPPER_BOILERPLATE( \
       n, false, signature \
     , RANK_1_FUNCTION_OBJECT \
     , RANK_1_INITIALIZER \
     , RANK_1_DISPATCHER \
     , RANK_1_ACCESSOR \
     , RANK_1_RESULT_TYPE \
   ) \
 /**/

#define CALL_SIGNATURE_CALL_WRAPPER(z, n, _) \
   RANK_1_CALL_WRAPPER(n, SIGNATURE_EXPRESSION) \
   RANK_1_CALL_WRAPPER(n, CALL_SIGNATURE) \
 /**/

// Generate call signature protocol specializations
BOOST_PP_REPEAT(
    BOOST_PP_INC(POLYMORPHIC_FUNCTION_MAX_ARITY)
  , CALL_SIGNATURE_CALL_WRAPPER
  , _
)

#undef CALL_SIGNATURE
#undef RANK_1_FUNCTION_OBJECT
#undef RANK_1_INITIALIZER
#undef RANK_1_DISPATCHER
#undef RANK_1_RESULT_TYPE
#undef RANK_1_CALL_WRAPPER
#undef CALL_SIGNATURE_CALL_WRAPPER

// Polymorphic signature protocol

#if BOOST_WORKAROUND( __GNUC__, < 4 )
#   define ACCESSOR_OVERLOAD_ARGUMENT \
      typename detail::std_::add_pointer<S>::type s = 0 \
    /**/
#else
#   define ACCESSOR_OVERLOAD_ARGUMENT
#endif

#if defined(POLYMORPHIC_FUNCTION_CPP0X)
#   define DISPATCH_ARGUMENT(z, n, _) \
      S ## n && s ## n \
    /**/
#   define ARGUMENT_TYPE decltype(detail::std_::forward<argument_type>(a))
#   define FORWARD_FUNCTION detail::std_::forward
#else
#   define DISPATCH_ARGUMENT(z, n, _) \
      S ## n  & s ## n \
    /**/
#   define ARGUMENT_TYPE argument_type
#   define FORWARD_FUNCTION static_cast
#endif

#define POLYMORPHIC_SIGNATURE(n, x) \
   signature< SIGNATURE_EXPRESSION(n, x) > \
 /**/

#define POLYMORPHIC_FORWARD_TYPE(z, n, _) \
   typename forward_type< T ## n , S ## n>::type \
 /**/

#define POLYMORPHIC_FORWARD(z, n, _) \
   FORWARD_FUNCTION< POLYMORPHIC_FORWARD_TYPE(z, n, _) >( s ## n ) \
 /**/

#define RANK_N_FUNCTION_OBJECT(n) \
   typename detail::functor_type< SIGNATURE_EXPRESSION(n, T) >::type \
 /**/

#define RANK_N_INITIALIZER(n) \
   polymorphic_function(callable_type g) \
       : f(g) \
   { \
   } \
 /**/

#define RANK_N_DISPATCHER(n, cv_qualification) \
   BOOST_PP_TUPLE_REM_CTOR( \
       n, BOOST_PP_IF(n, (template< BOOST_PP_ENUM_PARAMS(n, class S) >), ()) \
   ) \
   typename result< polymorphic_function ( BOOST_PP_ENUM_PARAMS(n, S) ) >::type \
   operator()( BOOST_PP_ENUM(n, DISPATCH_ARGUMENT, _) ) cv_qualification \
   { \
       return detail::std_::unwrap(f)( \
           BOOST_PP_ENUM(n, POLYMORPHIC_FORWARD, _) \
       ); \
   } \
 /**/

#define RANK_N_ACCESSOR(n, cv_qualification) \
   template<class S> \
   typename detail::std_::enable_if< \
       function_types::is_callable_builtin<callable_type>::value \
     , cv_qualification S* \
   >::type \
   target() cv_qualification \
   { \
       return f.target<S>(); \
   } \
   template<class S> \
   typename detail::std_::enable_if< \
       mpl::not_<function_types::is_callable_builtin<callable_type> >::value \
     , cv_qualification S* \
   >::type \
   target(ACCESSOR_OVERLOAD_ARGUMENT) cv_qualification \
   { \
       return &detail::std_::unwrap(f); \
   } \
/**/

#define RANK_N_RESULT_TYPE(n) \
   private: \
       typedef typename detail::callable_object_type< \
           SIGNATURE_EXPRESSION(n, T) \
       >::type callable_type; \
       template<class Requested, class Received> \
       class forward_type { \
           typedef typename mpl::if_< \
               mpl::is_placeholder<Requested> \
             , Received \
             , Requested \
           >::type argument_type; \
           static argument_type a; \
       public: \
           typedef ARGUMENT_TYPE type; \
       }; \
   public: \
       template<class> struct result; \
       template<class S BOOST_PP_ENUM_TRAILING_PARAMS(n, class S)>  \
       struct result< SIGNATURE_EXPRESSION(n, S) > \
           : detail::std_::result_of< \
                 callable_type( \
                     BOOST_PP_ENUM(n, POLYMORPHIC_FORWARD_TYPE, _) \
                 ) \
             > { \
       }; \
 /**/

#define RANK_N_CALL_WRAPPER(n, signature) \
   CALL_WRAPPER_BOILERPLATE( \
       n, true, signature \
     , RANK_N_FUNCTION_OBJECT \
     , RANK_N_INITIALIZER \
     , RANK_N_DISPATCHER \
     , RANK_N_ACCESSOR \
     , RANK_N_RESULT_TYPE \
   ) \
 /**/

#define POLYMORPHIC_SIGNATURE_CALL_WRAPPER(z, n, _) \
   RANK_N_CALL_WRAPPER(n, SIGNATURE_EXPRESSION) \
   RANK_N_CALL_WRAPPER(n, POLYMORPHIC_SIGNATURE) \
 /**/

// Generate polymorphic signature protocol specializations
BOOST_PP_REPEAT(
    BOOST_PP_INC(POLYMORPHIC_FUNCTION_MAX_ARITY)
  , POLYMORPHIC_SIGNATURE_CALL_WRAPPER
  , _
)

#undef ACCESSOR_OVERLOAD_ARGUMENT
#undef DISPATCH_ARGUMENT
#undef ARGUMENT_TYPE
#undef FORWARD_FUNCTION
#undef POLYMORPHIC_SIGNATURE
#undef POLYMORPHIC_FORWARD_TYPE
#undef POLYMORPHIC_FORWARD
#undef RANK_N_FUNCTION_OBJECT
#undef RANK_N_INITIALIZER
#undef RANK_N_DISPATCHER
#undef RANK_N_RESULT_TYPE
#undef RANK_N_CALL_WRAPPER
#undef POLYMORPHIC_SIGNATURE_CALL_WRAPPER

#undef CALL_WRAPPER_BOILERPLATE

//////////////////////////////////////////////////////////////////////
// Call wrapper conversion
//////////////////////////////////////////////////////////////////////

namespace detail {

template<class Signature, class F>
typename mpl::front<detail::components<Signature> >::type
target(F f)
{
    typedef typename detail::callable_object_type<Signature>::type callable_type;
    callable_type * p = f.template target<callable_type>();
    if(!p) throw std::bad_cast();
    return typename mpl::front<detail::components<Signature> >::type(*p);
}

} // namespace detail

template<class Signature1, class Signature2>
typename detail::std_::lazy_enable_if<
    mpl::and_<
        is_polymorphic_function<Signature1>
      , mpl::not_<is_incomplete_function<Signature1> >
    >::value
  , detail::call_erasure_type<Signature1>
>::type
functional_cast(detail::std_::function<Signature2> f)
{
    return detail::target<Signature1>(f);
}

template<class Signature1, class Signature2>
typename detail::std_::enable_if<
    mpl::not_<is_polymorphic_function<Signature1> >::value
  , detail::std_::function<typename call_signature<Signature1>::type>
>::type
functional_cast(detail::std_::function<Signature2> f)
{
    return f;
}

template<class Signature1, class Signature2>
typename detail::std_::enable_if<
    is_polymorphic_function<Signature1>::value
  , polymorphic_function<Signature1>
>::type
functional_cast(polymorphic_function<Signature2> f)
{
    return detail::target<Signature1>(f);
}

template<class Signature1, class Signature2>
typename detail::std_::enable_if<
    mpl::and_<
        mpl::not_<is_polymorphic_function<Signature1> >
      , is_polymorphic_function<Signature2>
    >::value
  , polymorphic_function<Signature1>
>::type
functional_cast(polymorphic_function<Signature2> f)
{
    return detail::target<Signature2>(f);
}

template<class Signature>
polymorphic_function<Signature>
functional_cast(polymorphic_function<Signature> f)
{
    return f;
}

#undef SIGNATURE_EXPRESSION

} // namespace functional
} // namespace boost

#endif // POLYMORPHIC_FUNCTION_HPP
