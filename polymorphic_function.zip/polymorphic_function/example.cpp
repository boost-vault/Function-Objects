//  Polymorphic function example

//  Copyright Daniel Walker 2008. Use, modification and
//  distribution is subject to the Boost Software License, Version
//  1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

#include <cassert>
#include <functional>
#include <numeric>

#include <boost/mpl/placeholders.hpp>
using boost::mpl::placeholders::_1;

#include "polymorphic_function.hpp"
using boost::functional::argument_of;
using boost::functional::functional_cast;
using boost::functional::is_polymorphic_function;
using boost::functional::polymorphic_function;

// Work with arbitrary callable objects without loss of polymorphism.
template<class Signature>
void do_division(polymorphic_function<Signature> f)
{
    // Do floating point division.
    float one = 1, two = 2;
    assert(f(one, two) == 0.5);

    if(is_polymorphic_function<Signature>::value) {
        // Now, drop the remainder using integer division.
        int one = 1, two = 2;
        assert(f(one, two) == 0);

        // And now, use high precision floating point division to
        // compute the inverse product of a series of integers.
        int series[3] = { 1, 2, 3 };
        double x = std::accumulate(&series[0], &series[3], 1.0,
                        functional_cast<double(double,double)>(f));
        assert(0.16666666 < x && x < 0.166666667);
    }
}

// A second class builtin function.
float builtin_divide(float x, float y)
{
    return x / y;
}

// A TR1 result_of compatible function object.
struct divide {
    template<class Signature>
    struct result : argument_of<Signature, 0> {
    };

    template<class T>
    T operator()(T x, T y) const
    {
        return x / y;
    }
};

int main()
{
    // Promote builtin functions to first class.
    do_division< float(float,float) >( builtin_divide );

    // Perform type-erasure.
    do_division< float(float,float) >( std::divides<float>() );

    // Use polymorphic function objects polymorphically.
    do_division< divide(_1,_1) >( divide() );
}
